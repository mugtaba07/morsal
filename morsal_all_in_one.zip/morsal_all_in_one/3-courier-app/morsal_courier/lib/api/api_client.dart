import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

import '../config.dart';
import 'api_exception.dart';

export 'api_exception.dart';

/// عميل HTTP بسيط: يضيف توكن المندوب في الرابط (كما يتوقع الباك إند)
/// ويحوّل الأخطاء إلى رسائل عربية مفهومة.
class ApiClient {
  ApiClient._();
  static final ApiClient instance = ApiClient._();

  String? token;

  /// يُستدعى عند انتهاء صلاحية الجلسة (401) لإعادة المستخدم لشاشة الدخول
  void Function()? onUnauthorized;

  Uri _uri(String path, Map<String, String>? query, bool auth) {
    final params = <String, String>{};
    if (query != null) params.addAll(query);
    final t = token;
    if (auth && t != null && t.isNotEmpty) params['token'] = t;
    final base = Uri.parse('$kBaseUrl$kApiPrefix$path');
    return params.isEmpty ? base : base.replace(queryParameters: params);
  }

  static const Map<String, String> _headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json; charset=UTF-8',
    'X-localization': 'ar',
  };

  Future<dynamic> get(String path, {Map<String, String>? query, bool auth = true}) {
    return _send(() => http.get(_uri(path, query, auth), headers: _headers), auth);
  }

  Future<dynamic> post(String path, {Map<String, dynamic>? body, bool auth = true}) {
    return _send(
      () => http.post(_uri(path, null, auth), headers: _headers, body: jsonEncode(body ?? <String, dynamic>{})),
      auth,
    );
  }

  Future<dynamic> put(String path, {Map<String, dynamic>? body, bool auth = true}) {
    return _send(
      () => http.put(_uri(path, null, auth), headers: _headers, body: jsonEncode(body ?? <String, dynamic>{})),
      auth,
    );
  }

  Future<dynamic> _send(Future<http.Response> Function() request, bool auth) async {
    http.Response res;
    try {
      res = await request().timeout(const Duration(seconds: 25));
    } on TimeoutException {
      throw const ApiException('انتهت مهلة الاتصال، تأكد من الإنترنت وحاول مرة أخرى');
    } on SocketException {
      throw const ApiException('تعذر الاتصال بالإنترنت');
    } on http.ClientException {
      throw const ApiException('تعذر الاتصال بالخادم');
    }

    dynamic data;
    try {
      final text = utf8.decode(res.bodyBytes);
      data = text.isEmpty ? null : jsonDecode(text);
    } catch (_) {
      data = null;
    }

    if (res.statusCode >= 200 && res.statusCode < 300) {
      return data;
    }
    if (res.statusCode == 401 && auth) {
      onUnauthorized?.call();
    }
    throw ApiException(_errorMessage(data, res.statusCode), statusCode: res.statusCode);
  }

  String _errorMessage(dynamic data, int status) {
    if (data is Map) {
      final errors = data['errors'];
      if (errors is List && errors.isNotEmpty) {
        final first = errors.first;
        if (first is Map && first['message'] != null) return first['message'].toString();
      }
      if (errors is Map && errors.isNotEmpty) {
        final v = errors.values.first;
        if (v is List && v.isNotEmpty) return v.first.toString();
        return v.toString();
      }
      if (data['message'] != null) return data['message'].toString();
    }
    return 'حدث خطأ غير متوقع ($status)';
  }
}
