<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('free_orders', function (Blueprint $table) {
            $table->string('pickup_landmark', 200)->nullable()->after('pickup_address');
            $table->string('drop_landmark', 200)->nullable()->after('drop_address');
        });
    }

    public function down()
    {
        Schema::table('free_orders', function (Blueprint $table) {
            $table->dropColumn(['pickup_landmark', 'drop_landmark']);
        });
    }
};
