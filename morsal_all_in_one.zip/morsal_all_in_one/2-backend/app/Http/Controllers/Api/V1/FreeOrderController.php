<?php

namespace App\Http\Controllers\Api\V1;

use App\CentralLogics\FreeOrderLogic;
use App\CentralLogics\Helpers;
use App\Http\Controllers\Controller;
use App\Models\BusinessSetting;
use App\Models\DeliveryMan;
use App\Models\FreeOrder;
use App\Models\FreeOrderOffer;
use App\Models\Module;
use App\Models\Order;
use App\Models\ParcelCategory;
use App\Models\Zone;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use MatanYadaev\EloquentSpatial\Objects\Point;

/**
 * الطلب الحر (أسلوب مرسول) - جهة العميل.
 * العميل ينشر طلبًا، يستقبل عروض المناديب، ويقبل عرضًا واحدًا فيتحول
 * الطلب إلى Order عادي مسند للمندوب (فتعمل المحادثة والتتبع والتقييم الحالية).
 */
class FreeOrderController extends Controller
{
    private function error($code, $message, $status = 403)
    {
        return response()->json(['errors' => [['code' => $code, 'message' => $message]]], $status);
    }

    // معامل تقريبي لتحويل المسافة المستقيمة إلى مسافة طريق فعلية
    private const ROAD_FACTOR = 1.3;

    private function resolveCategory($module_id)
    {
        $categories = ParcelCategory::where('module_id', $module_id)->where('status', 1)->get();
        return $categories->first(function ($c) {
            return in_array(trim($c->name), ['طلب حر', 'Free Order'], true);
        }) ?: $categories->first();
    }

    // تقريب الأجرة: خطوة التقريب تتناسب مع حجم المبلغ (مناسب للعملات ذات الأرقام الكبيرة)
    private function roundFee($fee)
    {
        if ($fee >= 10000) {
            $step = 500;
        } elseif ($fee >= 1000) {
            $step = 100;
        } elseif ($fee >= 100) {
            $step = 10;
        } else {
            $step = 1;
        }
        return (float)(ceil($fee / $step) * $step);
    }

    // GET customer/free-order/estimate?pickup_latitude=&pickup_longitude=&drop_latitude=&drop_longitude=
    // نفس معادلة الطرود: الأكبر بين (المسافة × سعر الكيلو) والحد الأدنى. الأسعار من فئة الطرود في لوحة الإدارة.
    public function estimate(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'pickup_latitude' => 'required|numeric|between:-90,90',
            'pickup_longitude' => 'required|numeric|between:-180,180',
            'drop_latitude' => 'required|numeric|between:-90,90',
            'drop_longitude' => 'required|numeric|between:-180,180',
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }

        $module = Module::where('module_type', 'parcel')->first();
        $category = $module ? $this->resolveCategory($module->id) : null;
        if (!$category) {
            return response()->json(['available' => false], 200);
        }

        $per_km = (float)$category->parcel_per_km_shipping_charge;
        $minimum = (float)$category->parcel_minimum_shipping_charge;
        if (!$per_km || !$minimum) {
            // نفس بديل نظام الطرود: الإعدادات العامة
            $per_km = (float)optional(BusinessSetting::where('key', 'parcel_per_km_shipping_charge')->first())->value;
            $minimum = (float)optional(BusinessSetting::where('key', 'parcel_minimum_shipping_charge')->first())->value;
        }
        if ($per_km <= 0 && $minimum <= 0) {
            return response()->json(['available' => false], 200);
        }

        $straight = FreeOrderLogic::distance_km(
            $request->pickup_latitude, $request->pickup_longitude, $request->drop_latitude, $request->drop_longitude
        );
        $distance = round($straight * self::ROAD_FACTOR, 1);
        $fee = max($distance * $per_km, $minimum);
        $suggested = $this->roundFee($fee);

        $options = array_values(array_unique([
            $suggested,
            $this->roundFee($fee * 1.15),
            $this->roundFee($fee * 1.3),
        ]));

        return response()->json([
            'available' => true,
            'distance_km' => $distance,
            'suggested_fee' => $suggested,
            'options' => $options,
        ], 200);
    }

    // POST customer/free-order/place
    public function place(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // الوصف مطلوب إلا إذا أُرسلت رسالة صوتية
            'description' => 'required_without:voice|nullable|string|max:1000',
            'voice' => 'nullable|file|mimes:m4a,mp4,aac,mp3,wav,ogg,3gp,amr,webm|max:4096',
            'drop_address' => 'required|string|max:500',
            'drop_latitude' => 'required|numeric|between:-90,90',
            'drop_longitude' => 'required|numeric|between:-180,180',
            'contact_person_name' => 'required|string|max:100',
            'contact_person_number' => 'required|string|max:30',
            'pickup_place_name' => 'nullable|string|max:150',
            'pickup_address' => 'nullable|string|max:500',
            'pickup_landmark' => 'nullable|string|max:200',
            'drop_landmark' => 'nullable|string|max:200',
            'pickup_latitude' => 'nullable|numeric|between:-90,90',
            'pickup_longitude' => 'nullable|numeric|between:-180,180',
            'estimated_item_price' => 'nullable|numeric|min:0',
            'suggested_delivery_fee' => 'nullable|numeric|min:0',
            'payment_method' => 'nullable|in:cash_on_delivery',
            'image' => 'nullable|image|max:5120',
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }

        $user = $request->user();
        FreeOrder::expireStale();

        if (FreeOrder::where('user_id', $user->id)->open()->count() >= FreeOrderLogic::MAX_OPEN_REQUESTS) {
            return $this->error('free_order_limit', translate('messages.free_order_limit_reached'));
        }

        // التحقق من أن موقع التسليم داخل منطقة مخدومة
        $zone_ids = json_decode($request->header('zoneId'), true);
        $zone = Zone::whereIn('id', (array)$zone_ids)
            ->whereContains('coordinates', new Point($request->drop_latitude, $request->drop_longitude, POINT_SRID))
            ->first();
        if (!$zone) {
            return $this->error('coordinates', translate('messages.out_of_coverage'));
        }

        $module = Module::where('module_type', 'parcel')->first();
        if (!$module) {
            return $this->error('module', translate('messages.module_not_found'), 404);
        }

        $voice = null;
        if ($request->hasFile('voice')) {
            $ext = strtolower($request->file('voice')->getClientOriginalExtension());
            if (!in_array($ext, ['m4a', 'mp4', 'aac', 'mp3', 'wav', 'ogg', '3gp', 'amr', 'webm'])) {
                $ext = 'm4a';
            }
            $voice = Helpers::upload('free_order_voice/', $ext, $request->file('voice'));
        }

        $free_order = FreeOrder::create([
            'user_id' => $user->id,
            'zone_id' => $zone->id,
            'module_id' => $module->id,
            'description' => $request->description ?? '',
            'voice' => $voice,
            'image' => $request->hasFile('image') ? Helpers::upload('order/', 'png', $request->file('image')) : null,
            'pickup_place_name' => $request->pickup_place_name,
            'pickup_address' => $request->pickup_address,
            'pickup_landmark' => $request->pickup_landmark,
            'pickup_latitude' => $request->pickup_latitude,
            'pickup_longitude' => $request->pickup_longitude,
            'drop_address' => $request->drop_address,
            'drop_landmark' => $request->drop_landmark,
            'drop_latitude' => $request->drop_latitude,
            'drop_longitude' => $request->drop_longitude,
            'contact_person_name' => $request->contact_person_name,
            'contact_person_number' => $request->contact_person_number,
            'estimated_item_price' => $request->estimated_item_price,
            'suggested_delivery_fee' => $request->suggested_delivery_fee,
            'payment_method' => 'cash_on_delivery',
            'status' => 'open',
            'expires_at' => now()->addMinutes(FreeOrderLogic::EXPIRY_MINUTES),
        ]);

        // إشعار المناديب النشطين في نفس المنطقة
        $tokens = DeliveryMan::where('zone_id', $zone->id)
            ->where('active', 1)
            ->where('application_status', 'approved')
            ->whereNotNull('fcm_token')
            ->limit(100)
            ->pluck('fcm_token');
        foreach ($tokens as $token) {
            FreeOrderLogic::push(
                $token,
                translate('messages.new_free_order_title'),
                $free_order->description !== ''
                    ? \Illuminate\Support\Str::limit($free_order->description, 80)
                    : translate('messages.free_order_voice_note'),
                $free_order->id,
                'free_order_new'
            );
        }

        return response()->json([
            'message' => translate('messages.free_order_sent'),
            'free_order_id' => $free_order->id,
            'expires_at' => $free_order->expires_at,
        ], 200);
    }

    // GET customer/free-order/list?limit=&offset=
    public function list(Request $request)
    {
        FreeOrder::expireStale();
        $paginator = FreeOrder::where('user_id', $request->user()->id)
            ->withCount(['offers as pending_offers_count' => function ($q) {
                $q->where('status', 'pending');
            }])
            ->latest()
            ->paginate($request['limit'] ?? 20, ['*'], 'page', $request['offset'] ?? 1);

        $items = collect($paginator->items())->map(function ($fo) {
            $row = FreeOrderLogic::format_request($fo);
            $row['pending_offers_count'] = (int)$fo->pending_offers_count;
            return $row;
        });

        return response()->json([
            'total_size' => $paginator->total(),
            'limit' => $request['limit'] ?? 20,
            'offset' => $request['offset'] ?? 1,
            'free_orders' => $items,
        ], 200);
    }

    // GET customer/free-order/details?id=
    public function details(Request $request)
    {
        $validator = Validator::make($request->all(), ['id' => 'required|integer']);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }
        FreeOrder::expireStale();

        $fo = FreeOrder::where('id', $request->id)->where('user_id', $request->user()->id)->first();
        if (!$fo) {
            return $this->error('free_order', translate('messages.not_found'), 404);
        }

        $accepted = $fo->status === 'accepted';
        $offers = FreeOrderOffer::with(['deliveryMan.rating'])
            ->where('free_order_id', $fo->id)
            ->when(!$accepted, function ($q) {
                $q->where('status', 'pending');
            }, function ($q) use ($fo) {
                $q->where('id', $fo->accepted_offer_id);
            })
            ->orderBy('price')
            ->get()
            ->map(function ($offer) use ($accepted) {
                // رقم المندوب يظهر للعميل فقط بعد قبول العرض
                return FreeOrderLogic::format_offer($offer, $accepted);
            });

        return response()->json([
            'free_order' => FreeOrderLogic::format_request($fo),
            'offers' => $offers,
        ], 200);
    }

    // PUT customer/free-order/accept-offer  {free_order_id, offer_id}
    public function accept_offer(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'free_order_id' => 'required|integer',
            'offer_id' => 'required|integer',
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }

        $user = $request->user();
        $rejected_tokens = [];
        $accepted_dm = null;
        $order = null;

        $result = DB::transaction(function () use ($request, $user, &$rejected_tokens, &$accepted_dm, &$order) {
            $fo = FreeOrder::where('id', $request->free_order_id)
                ->where('user_id', $user->id)
                ->lockForUpdate()
                ->first();
            if (!$fo) {
                return $this->error('free_order', translate('messages.not_found'), 404);
            }
            if ($fo->status !== 'open' || ($fo->expires_at && $fo->expires_at->isPast())) {
                return $this->error('free_order_closed', translate('messages.free_order_closed'));
            }

            $offer = FreeOrderOffer::where('id', $request->offer_id)
                ->where('free_order_id', $fo->id)
                ->where('status', 'pending')
                ->lockForUpdate()
                ->first();
            if (!$offer) {
                return $this->error('offer', translate('messages.offer_not_available'), 404);
            }

            $dm = DeliveryMan::where('id', $offer->delivery_man_id)->lockForUpdate()->first();
            if (!$dm || !$dm->active || $dm->application_status !== 'approved') {
                return $this->error('dm_unavailable', translate('messages.dm_unavailable'));
            }
            if ($dm->current_orders >= config('dm_maximum_orders')) {
                return $this->error('dm_maximum_order_exceed', translate('messages.dm_maximum_order_exceed_warning'), 405);
            }

            // فئة الطرود: المفضّلة اسمها "طلب حر" أو "Free Order"، وإلا أول فئة فعّالة في الوحدة
            $category = $this->resolveCategory($fo->module_id);
            if (!$category) {
                return $this->error('parcel_category', translate('messages.parcel_category_not_found'), 404);
            }

            // موقع نقطة الشراء: إن لم يحدده العميل نستخدم موقع التسليم كبديل مؤقت للخريطة
            $pickup_lat = $fo->pickup_latitude ?: $fo->drop_latitude;
            $pickup_lng = $fo->pickup_longitude ?: $fo->drop_longitude;
            $pickup_address = $fo->pickup_address ?: ($fo->pickup_place_name ?: $fo->drop_address);
            $landmark_label = translate('messages.nearest_landmark');
            if ($fo->pickup_landmark) {
                $pickup_address .= ' (' . $landmark_label . ': ' . $fo->pickup_landmark . ')';
            }
            $drop_address = $fo->drop_address;
            if ($fo->drop_landmark) {
                $drop_address .= ' (' . $landmark_label . ': ' . $fo->drop_landmark . ')';
            }

            $note = $fo->description;
            if ($fo->pickup_place_name) {
                $note .= "\n" . translate('messages.free_order_place_name') . ': ' . $fo->pickup_place_name;
            }
            if ($fo->estimated_item_price) {
                $note .= "\n" . translate('messages.free_order_item_price') . ': ' . $fo->estimated_item_price;
            }

            if ($fo->voice) {
                $note .= "\n" . translate('messages.free_order_voice_note') . ': '
                    . asset('storage/app/public/free_order_voice/' . $fo->voice);
            }
            $note = trim($note);

            $order = new Order();
            $order->id = 100000 + Order::count() + 1;
            if (Order::find($order->id)) {
                $order->id = Order::orderBy('id', 'desc')->first()->id + 1;
            }
            $order->user_id = $user->id;
            $order->order_amount = round($offer->price, config('round_up_to_digit'));
            $order->delivery_charge = round($offer->price, config('round_up_to_digit'));
            $order->original_delivery_charge = round($offer->price, config('round_up_to_digit'));
            $order->payment_status = 'unpaid';
            $order->payment_method = 'cash_on_delivery';
            $order->order_status = 'accepted';
            $order->order_type = 'parcel';
            $order->order_note = $note;
            $order->order_attachment = $fo->image;
            $order->zone_id = $fo->zone_id;
            $order->module_id = $fo->module_id;
            $order->parcel_category_id = $category->id;
            // المستلم هو من يدفع: حتى لا يطلب النظام رمز OTP عند الاستلام من المحل
            // (يُطلب الرمز من العميل عند التسليم فقط، وهذا هو المنطق الصحيح للطلب الحر)
            $order->charge_payer = 'receiver';
            $order->delivery_man_id = $dm->id;
            $order->delivery_address = json_encode([
                'contact_person_name' => $user->f_name . ' ' . $user->l_name,
                'contact_person_number' => $user->phone,
                'address_type' => 'Pickup',
                'address' => $pickup_address,
                'floor' => null,
                'road' => null,
                'house' => null,
                'longitude' => (string)$pickup_lng,
                'latitude' => (string)$pickup_lat,
            ]);
            $order->receiver_details = [
                'contact_person_name' => $fo->contact_person_name,
                'contact_person_number' => $fo->contact_person_number,
                'address_type' => 'Delivery',
                'address' => $drop_address,
                'longitude' => (string)$fo->drop_longitude,
                'latitude' => (string)$fo->drop_latitude,
            ];
            $order->distance = FreeOrderLogic::distance_km($pickup_lat, $pickup_lng, $fo->drop_latitude, $fo->drop_longitude) ?: 0;
            $order->otp = rand(1000, 9999);
            $order->dm_tips = 0;
            $order->additional_charge = 0;
            $order->total_tax_amount = 0;
            $order->tax_percentage = 0;
            $order->tax_status = 'excluded';
            $order->coupon_discount_amount = 0;
            $order->store_discount_amount = 0;
            $order->scheduled = 0;
            $order->schedule_at = now();
            $order->pending = now();
            $order->confirmed = now();
            $order->accepted = now();
            $order->created_at = now();
            $order->updated_at = now();
            $order->save();

            // إغلاق الطلب الحر وتحديث العروض
            $offer->status = 'accepted';
            $offer->save();
            FreeOrderOffer::where('free_order_id', $fo->id)
                ->where('id', '!=', $offer->id)
                ->where('status', 'pending')
                ->update(['status' => 'rejected']);

            $fo->status = 'accepted';
            $fo->accepted_offer_id = $offer->id;
            $fo->order_id = $order->id;
            $fo->save();

            $dm->current_orders = $dm->current_orders + 1;
            $dm->save();
            $dm->increment('assigned_order_count');
            $accepted_dm = $dm;

            $rejected_tokens = DeliveryMan::whereIn('id', FreeOrderOffer::where('free_order_id', $fo->id)
                ->where('status', 'rejected')->pluck('delivery_man_id'))
                ->whereNotNull('fcm_token')->pluck('fcm_token')->toArray();

            return response()->json([
                'message' => translate('messages.offer_accepted'),
                'order_id' => $order->id,
                'free_order_id' => $fo->id,
            ], 200);
        });

        // إشعارات بعد نجاح العملية (خارج المعاملة)
        if ($order && $accepted_dm) {
            FreeOrderLogic::push($accepted_dm->fcm_token, translate('messages.offer_accepted_title'),
                translate('messages.offer_accepted'), $order->id, 'order_status');
            foreach ($rejected_tokens as $token) {
                FreeOrderLogic::push($token, translate('messages.offer_rejected_title'),
                    translate('messages.offer_rejected'), $request->free_order_id, 'free_order_closed');
            }
        }

        return $result;
    }

    // PUT customer/free-order/reject-offer  {offer_id}
    public function reject_offer(Request $request)
    {
        $validator = Validator::make($request->all(), ['offer_id' => 'required|integer']);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }
        $offer = FreeOrderOffer::where('id', $request->offer_id)
            ->where('status', 'pending')
            ->whereHas('freeOrder', function ($q) use ($request) {
                $q->where('user_id', $request->user()->id)->where('status', 'open');
            })->first();
        if (!$offer) {
            return $this->error('offer', translate('messages.offer_not_available'), 404);
        }
        $offer->status = 'rejected';
        $offer->save();
        return response()->json(['message' => translate('messages.updated_successfully')], 200);
    }

    // PUT customer/free-order/cancel  {free_order_id}
    public function cancel(Request $request)
    {
        $validator = Validator::make($request->all(), ['free_order_id' => 'required|integer']);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }
        $fo = FreeOrder::where('id', $request->free_order_id)
            ->where('user_id', $request->user()->id)
            ->where('status', 'open')
            ->first();
        if (!$fo) {
            return $this->error('free_order', translate('messages.free_order_closed'), 404);
        }
        $fo->status = 'cancelled';
        $fo->save();
        FreeOrderOffer::where('free_order_id', $fo->id)->where('status', 'pending')->update(['status' => 'rejected']);
        return response()->json(['message' => translate('messages.order_canceled')], 200);
    }
}
