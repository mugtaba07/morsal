import 'package:flutter/material.dart';

import '../services/session.dart';

/// تنسيق الأرقام بفواصل الآلاف (1500 -> 1,500) وبدون كسور إذا كان الرقم صحيحًا
String formatNumber(num v) {
  final whole = v == v.roundToDouble();
  final fixed = whole ? v.round().toString() : v.toStringAsFixed(2);
  final parts = fixed.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (int i = 0; i < intPart.length; i++) {
    final fromEnd = intPart.length - i;
    buf.write(intPart[i]);
    if (fromEnd > 1 && fromEnd % 3 == 1 && intPart[i] != '-') {
      buf.write(',');
    }
  }
  if (parts.length > 1) buf.write('.${parts[1]}');
  return buf.toString();
}

/// المبلغ مع رمز العملة المضبوط من لوحة الإدارة
String money(num v) {
  final s = formatNumber(v);
  return Session.currencyAfter ? '$s ${Session.currencySymbol}' : '${Session.currencySymbol} $s';
}

/// يقرأ رقمًا مكتوبًا بأرقام عربية أو إنجليزية. الفاصلة تُتجاهل (فاصل آلاف)
/// والفاصلة العشرية العربية (٫) والنقطة تُعامل كفاصلة عشرية.
double? parseNumber(String input) {
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  final buf = StringBuffer();
  for (final ch in input.trim().split('')) {
    final i = arabicDigits.indexOf(ch);
    if (i >= 0) {
      buf.write(i);
    } else if (ch == '٫') {
      buf.write('.');
    } else if (ch == ',' || ch == '،' || ch == ' ') {
      continue;
    } else {
      buf.write(ch);
    }
  }
  return double.tryParse(buf.toString());
}

String remainingText(Duration? d) {
  if (d == null) return '';
  if (d.isNegative) return 'انتهت المهلة';
  if (d.inMinutes >= 1) return 'ينتهي بعد ${d.inMinutes} د';
  return 'ينتهي بعد ${d.inSeconds} ث';
}

void showSnack(BuildContext context, String message) {
  if (!context.mounted) return;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

class StatusChip extends StatelessWidget {
  final String text;
  final Color color;
  const StatusChip(this.text, this.color, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
    );
  }
}

/// شارة صغيرة بأيقونة ونص (مسافة، أجرة...)
class InfoPill extends StatelessWidget {
  final IconData icon;
  final String text;
  const InfoPill(this.icon, this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: scheme.outline.withAlpha(35), // لون محايد يعمل مع كل إصدارات Flutter
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 14, color: scheme.primary),
        const SizedBox(width: 4),
        Text(text, style: const TextStyle(fontSize: 12)),
      ]),
    );
  }
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;
  final String? hint;
  const EmptyState({super.key, required this.icon, required this.text, this.hint});

  @override
  Widget build(BuildContext context) {
    final grey = Theme.of(context).colorScheme.outline;
    return Padding(
      padding: const EdgeInsets.only(top: 100, left: 24, right: 24),
      child: Column(children: [
        Icon(icon, size: 64, color: grey),
        const SizedBox(height: 12),
        Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: grey)),
        if (hint != null) ...[
          const SizedBox(height: 6),
          Text(hint!, textAlign: TextAlign.center, style: TextStyle(fontSize: 13, color: grey)),
        ],
      ]),
    );
  }
}

class ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const ErrorView({super.key, required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.cloud_off, size: 56, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 12),
          Text(message, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          ElevatedButton(onPressed: onRetry, child: const Text('إعادة المحاولة')),
        ]),
      ),
    );
  }
}
