#!/usr/bin/env bash
# يشغّل اختبارات منطق تطبيق المندوب (Dart) والمعاينة التفاعلية (Node + jsdom).
# المتطلبات: Dart (يأتي مع Flutter). اختبار المعاينة يحتاج أيضًا: npm i jsdom
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/../3-courier-app/morsal_courier/lib"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "== نماذج البيانات والأرقام"
mkdir -p "$TMP/m" && cp "$SRC/models/models.dart" "$TMP/m/" && cp "$HERE/models_test.dart" "$TMP/m/t.dart"
(cd "$TMP/m" && dart run t.dart | tail -3)

echo "== الباك إند التجريبي (يستغرق ~10 ثوانٍ)"
mkdir -p "$TMP/d/api" "$TMP/d/models"
cp "$SRC/api/demo_backend.dart" "$SRC/api/api_exception.dart" "$TMP/d/api/" && cp "$SRC/models/models.dart" "$TMP/d/models/"
cp "$HERE/demo_backend_test.dart" "$TMP/d/t.dart"
(cd "$TMP/d" && dart run t.dart | tail -3)

if command -v node >/dev/null 2>&1 && node -e "require('jsdom')" 2>/dev/null; then
  echo "== المعاينة التفاعلية"
  node "$HERE/preview_test.js" | tail -3
else
  echo "== تخطي اختبار المعاينة (ثبّت jsdom: npm i jsdom)"
fi
