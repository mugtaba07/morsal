import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'api/api_client.dart';
import 'screens/home_shell.dart';
import 'screens/login_screen.dart';
import 'services/session.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
bool _loggingOut = false;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Session.load();

  // عند انتهاء صلاحية الجلسة نعيد المندوب لشاشة الدخول مرة واحدة فقط
  ApiClient.instance.onUnauthorized = () async {
    if (_loggingOut) return;
    _loggingOut = true;
    await Session.clear();
    navigatorKey.currentState?.pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
      (route) => false,
    );
    _loggingOut = false;
  };

  runApp(const CourierApp());
}

class CourierApp extends StatelessWidget {
  const CourierApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مندوب مرسال',
      debugShowCheckedModeBanner: false,
      navigatorKey: navigatorKey,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF039D55),
      ),
      home: Session.isLoggedIn ? const HomeShell() : const LoginScreen(),
    );
  }
}
