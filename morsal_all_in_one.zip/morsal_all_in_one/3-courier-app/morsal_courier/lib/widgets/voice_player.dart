import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

/// تشغيل رسالة العميل الصوتية من رابطها
class VoicePlayerButton extends StatefulWidget {
  final String url;
  const VoicePlayerButton({super.key, required this.url});

  @override
  State<VoicePlayerButton> createState() => _VoicePlayerButtonState();
}

class _VoicePlayerButtonState extends State<VoicePlayerButton> {
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription<void>? _sub;
  bool _playing = false;
  bool _loading = false;

  @override
  void initState() {
    super.initState();
    _sub = _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      if (_playing) {
        await _player.stop();
        if (mounted) setState(() => _playing = false);
        return;
      }
      setState(() => _loading = true);
      await _player.play(UrlSource(widget.url));
      if (mounted) {
        setState(() {
          _playing = true;
          _loading = false;
        });
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _playing = false;
        _loading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر تشغيل الرسالة الصوتية')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: _loading ? null : _toggle,
      icon: _loading
          ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
          : Icon(_playing ? Icons.stop_circle_outlined : Icons.play_circle_outline),
      label: Text(_playing ? 'إيقاف' : 'تشغيل الرسالة الصوتية'),
    );
  }
}
