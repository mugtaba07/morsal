import 'dart:async';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:morsal/data/api/api_checker.dart';
import 'package:morsal/data/api/api_client.dart';
import 'package:morsal/data/model/body/free_order_body.dart';
import 'package:morsal/data/model/response/address_model.dart';
import 'package:morsal/data/model/response/free_order_model.dart';
import 'package:morsal/data/repository/free_order_repo.dart';
import 'package:morsal/view/base/custom_snackbar.dart';

class FreeOrderController extends GetxController implements GetxService {
  final FreeOrderRepo freeOrderRepo;
  FreeOrderController({required this.freeOrderRepo});

  // ---- نموذج إنشاء الطلب ----
  AddressModel? _pickupAddress; // اختياري: قد يكتب العميل اسم المحل فقط
  AddressModel? _dropAddress;
  XFile? _pickedImage;
  String? _voicePath; // مسار التسجيل الصوتي المحلي (m4a)
  bool _isLoading = false;

  AddressModel? get pickupAddress => _pickupAddress;
  AddressModel? get dropAddress => _dropAddress;
  XFile? get pickedImage => _pickedImage;
  String? get voicePath => _voicePath;
  bool get isLoading => _isLoading;

  // ---- تقدير الأجرة ----
  FeeEstimateModel? _estimate;
  bool _isEstimating = false;
  int _estimateToken = 0; // لتجاهل ردود قديمة إذا غيّر العميل الموقع بسرعة

  FeeEstimateModel? get estimate => _estimate;
  bool get isEstimating => _isEstimating;

  // ---- قائمة طلباتي الحرة ----
  List<FreeOrderModel> _myRequests = [];
  int _listOffset = 1;
  int _listTotal = 0;
  bool _isListLoading = true;
  bool _isListLoadingMore = false;

  List<FreeOrderModel> get myRequests => _myRequests;
  bool get isListLoading => _isListLoading;
  bool get isListLoadingMore => _isListLoadingMore;
  bool get hasMoreRequests => _myRequests.length < _listTotal;

  // ---- شاشة العروض ----
  FreeOrderModel? _current;
  List<FreeOrderOfferModel> _offers = [];
  bool _isDetailsLoading = true;
  bool _isActionLoading = false;
  Timer? _poller;

  FreeOrderModel? get current => _current;
  List<FreeOrderOfferModel> get offers => _offers;
  bool get isDetailsLoading => _isDetailsLoading;
  bool get isActionLoading => _isActionLoading;

  void resetForm() {
    _pickupAddress = null;
    _dropAddress = null;
    _pickedImage = null;
    _voicePath = null;
    _estimate = null;
    _isEstimating = false;
    _isLoading = false;
  }

  void setVoicePath(String? path) {
    _voicePath = path;
    update();
  }

  void setPickupAddress(AddressModel? address) {
    _pickupAddress = address;
    update();
  }

  void setDropAddress(AddressModel? address) {
    _dropAddress = address;
    update();
  }

  Future<void> pickImage() async {
    final XFile? file = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (file != null) {
      _pickedImage = file;
      update();
    }
  }

  void removeImage() {
    _pickedImage = null;
    update();
  }

  /// يرسل الطلب ويعيد رقم الطلب الحر عند النجاح (أو null عند الفشل)
  Future<int?> submit(FreeOrderBody body) async {
    _isLoading = true;
    update();
    final Response response = await freeOrderRepo.placeFreeOrder(
      body,
      _pickedImage != null ? MultipartBody('image', _pickedImage) : null,
      _voicePath != null ? MultipartBody('voice', XFile(_voicePath!), fileName: 'voice.m4a') : null,
    );
    _isLoading = false;
    update();
    if (response.statusCode == 200) {
      showCustomSnackBar('free_order_sent'.tr, isError: false);
      return int.tryParse(response.body['free_order_id'].toString());
    }
    ApiChecker.checkApi(response);
    return null;
  }

  // ---------- تقدير الأجرة ----------

  /// يطلب الأجرة المقترحة عند توفر موقع الشراء وموقع التسليم معًا
  Future<void> fetchEstimate() async {
    final p = _pickupAddress;
    final d = _dropAddress;
    final int token = ++_estimateToken;
    if (p?.latitude == null || p?.longitude == null || d?.latitude == null || d?.longitude == null) {
      _estimate = null;
      _isEstimating = false;
      update();
      return;
    }
    _isEstimating = true;
    update();
    final Response response = await freeOrderRepo.getEstimate(p!.latitude!, p.longitude!, d!.latitude!, d.longitude!);
    if (token != _estimateToken) return; // وصل رد أحدث
    _estimate = response.statusCode == 200 ? FeeEstimateModel.fromJson(response.body) : null;
    _isEstimating = false;
    update();
  }

  // ---------- قائمة الطلبات ----------

  Future<void> loadMyRequests({bool reload = true}) async {
    if (reload) {
      _listOffset = 1;
      _isListLoading = true;
      update();
    } else {
      if (_isListLoadingMore || !hasMoreRequests) return;
      _isListLoadingMore = true;
      _listOffset++;
      update();
    }
    final Response response = await freeOrderRepo.getList(_listOffset);
    if (response.statusCode == 200) {
      final List<FreeOrderModel> page = [];
      for (final o in (response.body['free_orders'] as List? ?? [])) {
        page.add(FreeOrderModel.fromJson(o));
      }
      if (reload) {
        _myRequests = page;
      } else {
        _myRequests.addAll(page);
      }
      _listTotal = int.tryParse(response.body['total_size'].toString()) ?? _myRequests.length;
    } else {
      if (!reload) _listOffset--;
      ApiChecker.checkApi(response);
    }
    _isListLoading = false;
    _isListLoadingMore = false;
    update();
  }

  // ---------- العروض ----------

  Future<void> loadDetails(int id, {bool silent = false}) async {
    if (!silent) {
      _isDetailsLoading = true;
      update();
    }
    final Response response = await freeOrderRepo.getDetails(id);
    if (response.statusCode == 200) {
      _current = FreeOrderModel.fromJson(response.body['free_order']);
      _offers = [];
      for (final o in (response.body['offers'] as List? ?? [])) {
        _offers.add(FreeOrderOfferModel.fromJson(o));
      }
      // لا حاجة للاستعلام المتكرر بعد إغلاق الطلب
      if (_current != null && !_current!.isOpen) {
        stopPolling();
      }
    } else if (!silent) {
      ApiChecker.checkApi(response);
    }
    _isDetailsLoading = false;
    update();
  }

  /// استعلام دوري كل 8 ثوانٍ لالتقاط العروض الجديدة بينما الشاشة مفتوحة
  void startPolling(int id) {
    stopPolling();
    _poller = Timer.periodic(const Duration(seconds: 8), (_) => loadDetails(id, silent: true));
  }

  void stopPolling() {
    _poller?.cancel();
    _poller = null;
  }

  void clearDetails() {
    stopPolling();
    _current = null;
    _offers = [];
    _isDetailsLoading = true;
  }

  /// يقبل العرض ويعيد رقم الطلب العادي (للانتقال إلى التتبع) أو null
  Future<int?> acceptOffer(int freeOrderId, int offerId) async {
    _isActionLoading = true;
    update();
    final Response response = await freeOrderRepo.acceptOffer(freeOrderId, offerId);
    _isActionLoading = false;
    if (response.statusCode == 200) {
      stopPolling();
      update();
      return int.tryParse(response.body['order_id'].toString());
    }
    update();
    ApiChecker.checkApi(response);
    // قد يكون العرض سُحب أو انتهى الطلب: حدّث القائمة
    loadDetails(freeOrderId, silent: true);
    return null;
  }

  Future<void> rejectOffer(int freeOrderId, int offerId) async {
    final Response response = await freeOrderRepo.rejectOffer(offerId);
    if (response.statusCode == 200) {
      _offers.removeWhere((o) => o.id == offerId);
      update();
    } else {
      ApiChecker.checkApi(response);
      loadDetails(freeOrderId, silent: true);
    }
  }

  Future<bool> cancelRequest(int freeOrderId) async {
    _isActionLoading = true;
    update();
    final Response response = await freeOrderRepo.cancel(freeOrderId);
    _isActionLoading = false;
    update();
    if (response.statusCode == 200) {
      stopPolling();
      return true;
    }
    ApiChecker.checkApi(response);
    return false;
  }

  @override
  void onClose() {
    stopPolling();
    super.onClose();
  }
}
