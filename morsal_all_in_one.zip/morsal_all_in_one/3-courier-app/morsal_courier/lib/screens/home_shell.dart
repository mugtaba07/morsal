import 'dart:async';

import 'package:flutter/material.dart';

import '../api/api_client.dart';
import '../api/courier_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../services/location_service.dart';
import '../widgets/common.dart';
import 'nearby_tab.dart';
import 'offers_tab.dart';
import 'orders_tab.dart';
import 'profile_tab.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  int _index = 0;
  CourierProfile? _profile;
  Timer? _locationTimer;
  bool _reporting = false;
  bool _toggling = false;
  bool _firstProfileLoad = true;

  static const List<String> _titles = ['الطلبات القريبة', 'طلباتي الحالية', 'عروضي', 'حسابي'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadProfile();
    _locationTimer = Timer.periodic(kLocationInterval, (_) => _reportLocation());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _locationTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final p = await CourierApi.profile();
      if (!mounted) return;
      setState(() => _profile = p);
      if (_firstProfileLoad) {
        _firstProfileLoad = false;
        _reportLocation();
      }
    } on ApiException catch (_) {
      // نبقي آخر بيانات معروفة
    }
  }

  Future<void> _toggleActive() async {
    if (_toggling) return;
    setState(() => _toggling = true);
    try {
      await CourierApi.toggleActive();
      await _loadProfile();
    } on ApiException catch (e) {
      showSnack(context, e.message);
    } finally {
      if (mounted) setState(() => _toggling = false);
    }
  }

  /// يرسل موقع المندوب للسيرفر (فقط أثناء كونه متاحًا والتطبيق مفتوح)
  Future<void> _reportLocation() async {
    final p = _profile;
    if (_reporting || p == null || !p.active) return;
    _reporting = true;
    try {
      final pos = await LocationService.current();
      if (pos != null) {
        await CourierApi.recordLocation(pos.latitude, pos.longitude);
      }
    } catch (_) {
      // لا نزعج المندوب بأخطاء الموقع
    } finally {
      _reporting = false;
    }
  }

  Widget _body() {
    switch (_index) {
      case 0:
        return NearbyTab(active: _profile?.active ?? true);
      case 1:
        return const OrdersTab();
      case 2:
        return const OffersTab();
      default:
        return ProfileTab(
          profile: _profile,
          onRefresh: _loadProfile,
          onToggleActive: _toggleActive,
          toggling: _toggling,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = _profile;
    return Scaffold(
      appBar: AppBar(
        title: Text(_titles[_index]),
        actions: [
          if (p != null)
            Row(children: [
              Text(
                p.active ? 'متاح' : 'غير متاح',
                style: TextStyle(fontSize: 13, color: p.active ? Colors.green.shade700 : Colors.grey),
              ),
              Switch(value: p.active, onChanged: _toggling ? null : (_) => _toggleActive()),
              const SizedBox(width: 8),
            ]),
        ],
      ),
      body: _body(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.near_me_outlined), selectedIcon: Icon(Icons.near_me), label: 'القريبة'),
          NavigationDestination(icon: Icon(Icons.delivery_dining_outlined), selectedIcon: Icon(Icons.delivery_dining), label: 'طلباتي'),
          NavigationDestination(icon: Icon(Icons.local_offer_outlined), selectedIcon: Icon(Icons.local_offer), label: 'عروضي'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}
