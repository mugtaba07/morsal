import 'dart:convert';

double? asDouble(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString());
}

int? asInt(dynamic v) {
  if (v == null) return null;
  if (v is num) return v.toInt();
  return int.tryParse(v.toString());
}

String? asString(dynamic v) {
  if (v == null) return null;
  final s = v.toString();
  return s.isEmpty ? null : s;
}

bool asBool(dynamic v) {
  if (v is bool) return v;
  if (v is num) return v != 0;
  if (v is String) return v == '1' || v.toLowerCase() == 'true';
  return false;
}

DateTime? asDate(dynamic v) {
  if (v == null) return null;
  final d = DateTime.tryParse(v.toString());
  return d?.toLocal();
}

/// يقبل Map أو نص JSON (بعض الحقول تصل بأحد الشكلين حسب إعداد الباك إند)
Map<String, dynamic>? asMap(dynamic v) {
  if (v is Map) return Map<String, dynamic>.from(v);
  if (v is String && v.isNotEmpty) {
    try {
      final d = jsonDecode(v);
      if (d is Map) return Map<String, dynamic>.from(d);
    } catch (_) {}
  }
  return null;
}

List<dynamic> asList(dynamic v) => v is List ? v : const <dynamic>[];

// ---------------------------------------------------------------------------

class MyOfferInfo {
  final int id;
  final double price;
  final int? etaMinutes;
  final String status; // pending | accepted | rejected | withdrawn

  const MyOfferInfo({required this.id, required this.price, this.etaMinutes, required this.status});

  factory MyOfferInfo.fromJson(Map<String, dynamic> j) => MyOfferInfo(
        id: asInt(j['id']) ?? 0,
        price: asDouble(j['price']) ?? 0,
        etaMinutes: asInt(j['eta_minutes']),
        status: asString(j['status']) ?? 'pending',
      );

  bool get isPending => status == 'pending';
}

/// طلب حر منشور من عميل (يظهر في تبويب الطلبات القريبة)
class FreeRequest {
  final int id;
  final String description;
  final String? image;
  final String? voiceUrl;
  final String? pickupPlaceName;
  final String? pickupAddress;
  final String? pickupLandmark;
  final double? pickupLat;
  final double? pickupLng;
  final String dropAddress;
  final String? dropLandmark;
  final double? dropLat;
  final double? dropLng;
  final double? estimatedItemPrice;
  final double? suggestedFee;
  final DateTime? expiresAt;
  final double? distanceToPickupKm;
  final double? tripDistanceKm;
  final String? customerName;
  final MyOfferInfo? myOffer;

  const FreeRequest({
    required this.id,
    required this.description,
    this.image,
    this.voiceUrl,
    this.pickupPlaceName,
    this.pickupAddress,
    this.pickupLandmark,
    this.pickupLat,
    this.pickupLng,
    required this.dropAddress,
    this.dropLandmark,
    this.dropLat,
    this.dropLng,
    this.estimatedItemPrice,
    this.suggestedFee,
    this.expiresAt,
    this.distanceToPickupKm,
    this.tripDistanceKm,
    this.customerName,
    this.myOffer,
  });

  factory FreeRequest.fromJson(Map<String, dynamic> j) {
    final mine = asMap(j['my_offer']);
    return FreeRequest(
      id: asInt(j['id']) ?? 0,
      description: asString(j['description']) ?? '',
      image: asString(j['image']),
      voiceUrl: asString(j['voice_url']),
      pickupPlaceName: asString(j['pickup_place_name']),
      pickupAddress: asString(j['pickup_address']),
      pickupLandmark: asString(j['pickup_landmark']),
      pickupLat: asDouble(j['pickup_latitude']),
      pickupLng: asDouble(j['pickup_longitude']),
      dropAddress: asString(j['drop_address']) ?? '',
      dropLandmark: asString(j['drop_landmark']),
      dropLat: asDouble(j['drop_latitude']),
      dropLng: asDouble(j['drop_longitude']),
      estimatedItemPrice: asDouble(j['estimated_item_price']),
      suggestedFee: asDouble(j['suggested_delivery_fee']),
      expiresAt: asDate(j['expires_at']),
      distanceToPickupKm: asDouble(j['distance_to_pickup_km']),
      tripDistanceKm: asDouble(j['trip_distance_km']),
      customerName: asString(j['customer_name']),
      myOffer: mine == null ? null : MyOfferInfo.fromJson(mine),
    );
  }

  bool get hasVoice => (voiceUrl ?? '').isNotEmpty;
  bool get hasPickupLocation => pickupLat != null && pickupLng != null;
  bool get hasDropLocation => dropLat != null && dropLng != null;

  Duration? get remaining => expiresAt?.difference(DateTime.now());
}

/// عرض قدّمه المندوب (تبويب عروضي)
class OfferItem {
  final int id;
  final int freeOrderId;
  final double price;
  final int? etaMinutes;
  final String? note;
  final String status;
  final DateTime? createdAt;
  final String requestDescription;
  final String requestStatus;
  final int? orderId;

  const OfferItem({
    required this.id,
    required this.freeOrderId,
    required this.price,
    this.etaMinutes,
    this.note,
    required this.status,
    this.createdAt,
    required this.requestDescription,
    required this.requestStatus,
    this.orderId,
  });

  factory OfferItem.fromJson(Map<String, dynamic> j) {
    final fo = asMap(j['free_order']);
    return OfferItem(
      id: asInt(j['id']) ?? 0,
      freeOrderId: asInt(j['free_order_id']) ?? 0,
      price: asDouble(j['price']) ?? 0,
      etaMinutes: asInt(j['eta_minutes']),
      note: asString(j['note']),
      status: asString(j['status']) ?? 'pending',
      createdAt: asDate(j['created_at']),
      requestDescription: asString(fo?['description']) ?? '',
      requestStatus: asString(fo?['status']) ?? '',
      orderId: asInt(fo?['order_id']),
    );
  }

  bool get isPending => status == 'pending';
}

class OrderPoint {
  final String? name;
  final String? phone;
  final String? address;
  final double? lat;
  final double? lng;

  const OrderPoint({this.name, this.phone, this.address, this.lat, this.lng});

  factory OrderPoint.fromJson(Map<String, dynamic>? j) {
    if (j == null) return const OrderPoint();
    return OrderPoint(
      name: asString(j['contact_person_name']),
      phone: asString(j['contact_person_number']),
      address: asString(j['address']),
      lat: asDouble(j['latitude']),
      lng: asDouble(j['longitude']),
    );
  }

  bool get hasLocation => lat != null && lng != null;
}

/// طلب مُسند للمندوب بعد قبول العميل لعرضه (تبويب طلباتي)
class CourierOrder {
  final int id;
  final String status;
  final String note;
  final double deliveryCharge;
  final String paymentMethod;
  final OrderPoint pickup;
  final OrderPoint drop;
  final String? customerName;
  final String? customerPhone;

  const CourierOrder({
    required this.id,
    required this.status,
    required this.note,
    required this.deliveryCharge,
    required this.paymentMethod,
    required this.pickup,
    required this.drop,
    this.customerName,
    this.customerPhone,
  });

  factory CourierOrder.fromJson(Map<String, dynamic> j) {
    final customer = asMap(j['customer']);
    final fullName = customer == null
        ? null
        : '${asString(customer['f_name']) ?? ''} ${asString(customer['l_name']) ?? ''}'.trim();
    return CourierOrder(
      id: asInt(j['id']) ?? 0,
      status: asString(j['order_status']) ?? '',
      note: asString(j['order_note']) ?? '',
      deliveryCharge: asDouble(j['delivery_charge']) ?? 0,
      paymentMethod: asString(j['payment_method']) ?? '',
      pickup: OrderPoint.fromJson(asMap(j['delivery_address'])),
      drop: OrderPoint.fromJson(asMap(j['receiver_details'])),
      customerName: (fullName == null || fullName.isEmpty) ? null : fullName,
      customerPhone: asString(customer?['phone']),
    );
  }

  static final RegExp _voiceRe = RegExp(r'https?://\S+/free_order_voice/\S+');

  /// رابط الرسالة الصوتية إن أضافه النظام داخل ملاحظة الطلب
  String? get voiceUrl => _voiceRe.firstMatch(note)?.group(0);

  /// الملاحظة دون سطر رابط الصوت
  String get noteText {
    return note
        .split('\n')
        .where((line) => !_voiceRe.hasMatch(line))
        .join('\n')
        .trim();
  }

  bool get isPickedUp => status == 'picked_up';
  String get contactPhone => customerPhone ?? drop.phone ?? '';
}

class CourierProfile {
  final String name;
  final String phone;
  final bool active;
  final double? rating;
  final int ratingCount;
  final int orderCount;
  final int currentOrders;
  final double todaysEarning;
  final double weekEarning;
  final double monthEarning;
  final double cashInHands;
  final double balance;

  const CourierProfile({
    required this.name,
    required this.phone,
    required this.active,
    this.rating,
    this.ratingCount = 0,
    this.orderCount = 0,
    this.currentOrders = 0,
    this.todaysEarning = 0,
    this.weekEarning = 0,
    this.monthEarning = 0,
    this.cashInHands = 0,
    this.balance = 0,
  });

  factory CourierProfile.fromJson(Map<String, dynamic> j) => CourierProfile(
        name: '${asString(j['f_name']) ?? ''} ${asString(j['l_name']) ?? ''}'.trim(),
        phone: asString(j['phone']) ?? '',
        active: asBool(j['active']),
        rating: asDouble(j['avg_rating']),
        ratingCount: asInt(j['rating_count']) ?? 0,
        orderCount: asInt(j['order_count']) ?? 0,
        currentOrders: asInt(j['current_orders']) ?? 0,
        todaysEarning: asDouble(j['todays_earning']) ?? 0,
        weekEarning: asDouble(j['this_week_earning']) ?? 0,
        monthEarning: asDouble(j['this_month_earning']) ?? 0,
        cashInHands: asDouble(j['cash_in_hands']) ?? 0,
        balance: asDouble(j['balance']) ?? 0,
      );
}
