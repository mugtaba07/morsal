import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:morsal/controller/free_order_controller.dart';
import 'package:morsal/controller/splash_controller.dart';
import 'package:morsal/data/model/response/free_order_model.dart';
import 'package:morsal/helper/price_converter.dart';
import 'package:morsal/helper/route_helper.dart';
import 'package:morsal/util/dimensions.dart';
import 'package:morsal/util/styles.dart';
import 'package:morsal/view/base/custom_app_bar.dart';
import 'package:morsal/view/base/custom_button.dart';
import 'package:morsal/view/base/custom_image.dart';
import 'package:morsal/view/screens/free_order/widget/voice_note_widget.dart';

/// شاشة عروض المناديب على الطلب الحر: تتحدث تلقائيًا كل 8 ثوانٍ.
class FreeOrderOffersScreen extends StatefulWidget {
  final int freeOrderId;
  const FreeOrderOffersScreen({Key? key, required this.freeOrderId}) : super(key: key);

  @override
  State<FreeOrderOffersScreen> createState() => _FreeOrderOffersScreenState();
}

class _FreeOrderOffersScreenState extends State<FreeOrderOffersScreen> {
  Timer? _clock; // لتحديث العدّاد التنازلي كل ثانية

  @override
  void initState() {
    super.initState();
    final controller = Get.find<FreeOrderController>();
    controller.clearDetails();
    controller.loadDetails(widget.freeOrderId);
    controller.startPolling(widget.freeOrderId);
    _clock = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _clock?.cancel();
    Get.find<FreeOrderController>().stopPolling();
    super.dispose();
  }

  String _remainingText(Duration? d) {
    if (d == null || d.isNegative) return '';
    final m = d.inMinutes.toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Future<void> _confirmAccept(FreeOrderController c, FreeOrderOfferModel offer) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('free_order_accept_title'.tr),
        content: Text('${offer.deliveryManName ?? ''}\n${PriceConverter.convertPrice(offer.price)}'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: Text('cancel'.tr)),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: Text('free_order_accept_offer'.tr)),
        ],
      ),
    );
    if (ok != true) return;
    final int? orderId = await c.acceptOffer(widget.freeOrderId, offer.id!);
    if (orderId != null) {
      Get.offNamed(RouteHelper.getOrderDetailsRoute(orderId));
    }
  }

  Future<void> _confirmCancel(FreeOrderController c) async {
    final bool? ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('free_order_cancel_title'.tr),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: Text('no'.tr)),
          TextButton(onPressed: () => Navigator.of(ctx).pop(true), child: Text('yes'.tr)),
        ],
      ),
    );
    if (ok == true && await c.cancelRequest(widget.freeOrderId)) {
      Get.back();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'free_order_offers_title'.tr),
      body: SafeArea(
        child: GetBuilder<FreeOrderController>(builder: (c) {
          if (c.isDetailsLoading || c.current == null) {
            return const Center(child: CircularProgressIndicator());
          }
          final FreeOrderModel order = c.current!;
          return Column(children: [
            Expanded(child: RefreshIndicator(
              onRefresh: () => c.loadDetails(widget.freeOrderId, silent: true),
              child: ListView(
                padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                children: [
                  _summaryCard(context, order),
                  const SizedBox(height: Dimensions.paddingSizeDefault),
                  if (order.isOpen) _waitingRow(context, order, c.offers.isEmpty),
                  if (order.isAccepted) _stateBox(context, Icons.check_circle, 'free_order_accepted_state'.tr, Theme.of(context).primaryColor),
                  if (!order.isOpen && !order.isAccepted)
                    _stateBox(context, Icons.info_outline, order.status == 'expired' ? 'free_order_expired_state'.tr : 'free_order_cancelled_state'.tr, Theme.of(context).disabledColor),
                  const SizedBox(height: Dimensions.paddingSizeSmall),
                  ...c.offers.map((o) => _offerCard(context, c, order, o)),
                ],
              ),
            )),
            if (order.isOpen) CustomButton(
              margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
              buttonText: 'free_order_cancel_request'.tr,
              transparent: true,
              isLoading: c.isActionLoading,
              onPressed: c.isActionLoading ? null : () => _confirmCancel(c),
            ),
            if (order.isAccepted && order.orderId != null) CustomButton(
              margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
              buttonText: 'free_order_track'.tr,
              onPressed: () => Get.offNamed(RouteHelper.getOrderDetailsRoute(order.orderId)),
            ),
            if (!order.isOpen && !order.isAccepted) CustomButton(
              margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
              buttonText: 'free_order_new_request'.tr,
              onPressed: () => Get.offNamed(RouteHelper.getFreeOrderRoute()),
            ),
          ]);
        }),
      ),
    );
  }

  Widget _summaryCard(BuildContext context, FreeOrderModel o) {
    return Container(
      padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
        border: Border.all(color: Theme.of(context).disabledColor.withOpacity(0.4)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if ((o.description ?? '').isNotEmpty) Text(o.description!, style: robotoMedium, maxLines: 3, overflow: TextOverflow.ellipsis),
        if ((o.voiceUrl ?? '').isNotEmpty) Padding(
          padding: const EdgeInsets.only(top: Dimensions.paddingSizeExtraSmall),
          child: Align(alignment: AlignmentDirectional.centerStart, child: VoicePlayerChip(url: o.voiceUrl!)),
        ),
        const SizedBox(height: Dimensions.paddingSizeSmall),
        if ((o.pickupPlaceName ?? '').isNotEmpty) Row(children: [
          Icon(Icons.store_mall_directory_outlined, size: 18, color: Theme.of(context).primaryColor),
          const SizedBox(width: Dimensions.paddingSizeExtraSmall),
          Expanded(child: Text(o.pickupPlaceName!, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall))),
        ]),
        const SizedBox(height: Dimensions.paddingSizeExtraSmall),
        Row(children: [
          Icon(Icons.location_on_outlined, size: 18, color: Theme.of(context).primaryColor),
          const SizedBox(width: Dimensions.paddingSizeExtraSmall),
          Expanded(child: Text(
              [o.dropAddress ?? '', if ((o.dropLandmark ?? '').isNotEmpty) '(${o.dropLandmark})'].join(' '),
              maxLines: 3, overflow: TextOverflow.ellipsis,
              style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall))),
        ]),
      ]),
    );
  }

  Widget _waitingRow(BuildContext context, FreeOrderModel order, bool noOffersYet) {
    final remaining = _remainingText(order.remaining);
    return Row(children: [
      SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Theme.of(context).primaryColor)),
      const SizedBox(width: Dimensions.paddingSizeSmall),
      Expanded(child: Text(
        noOffersYet ? 'free_order_waiting_offers'.tr : 'free_order_more_offers_may_come'.tr,
        style: robotoRegular.copyWith(color: Theme.of(context).primaryColor),
      )),
      if (remaining.isNotEmpty) Text(remaining, style: robotoMedium.copyWith(color: Theme.of(context).disabledColor)),
    ]);
  }

  Widget _stateBox(BuildContext context, IconData icon, String text, Color color) {
    return Row(children: [
      Icon(icon, color: color),
      const SizedBox(width: Dimensions.paddingSizeSmall),
      Expanded(child: Text(text, style: robotoMedium.copyWith(color: color))),
    ]);
  }

  Widget _offerCard(BuildContext context, FreeOrderController c, FreeOrderModel order, FreeOrderOfferModel offer) {
    final String imageBase = Get.find<SplashController>().configModel?.baseUrls?.deliveryManImageUrl ?? '';
    final bool canAct = order.isOpen;
    return Container(
      margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
      padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(Dimensions.radiusLarge),
        border: Border.all(color: Theme.of(context).disabledColor.withOpacity(0.4)),
      ),
      child: Column(children: [
        Row(children: [
          ClipOval(child: CustomImage(
            image: '$imageBase/${offer.deliveryManImage ?? ''}', height: 44, width: 44, fit: BoxFit.cover,
          )),
          const SizedBox(width: Dimensions.paddingSizeSmall),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(offer.deliveryManName ?? '', style: robotoBold),
            const SizedBox(height: 2),
            Row(children: [
              const Icon(Icons.star, size: 14, color: Colors.amber),
              const SizedBox(width: 2),
              Text(offer.rating != null ? offer.rating!.toStringAsFixed(1) : '-', style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall)),
              if (offer.ordersCount != null) Text('  •  ${offer.ordersCount} ${'orders'.tr}',
                  style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor)),
            ]),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(PriceConverter.convertPrice(offer.price), style: robotoBold.copyWith(fontSize: Dimensions.fontSizeLarge, color: Theme.of(context).primaryColor)),
            if (offer.etaMinutes != null) Text('${'free_order_arrives_in'.tr} ${offer.etaMinutes} ${'free_order_minute'.tr}',
                style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).disabledColor)),
          ]),
        ]),
        if ((offer.note ?? '').isNotEmpty) Align(
          alignment: AlignmentDirectional.centerStart,
          child: Padding(
            padding: const EdgeInsets.only(top: Dimensions.paddingSizeSmall),
            child: Text(offer.note!, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall)),
          ),
        ),
        if (canAct) Padding(
          padding: const EdgeInsets.only(top: Dimensions.paddingSizeDefault),
          child: Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: c.isActionLoading ? null : () => c.rejectOffer(widget.freeOrderId, offer.id!),
              child: Text('free_order_ignore'.tr),
            )),
            const SizedBox(width: Dimensions.paddingSizeSmall),
            Expanded(child: ElevatedButton(
              onPressed: c.isActionLoading ? null : () => _confirmAccept(c, offer),
              style: ElevatedButton.styleFrom(backgroundColor: Theme.of(context).primaryColor),
              child: Text('free_order_accept_offer'.tr, style: const TextStyle(color: Colors.white)),
            )),
          ]),
        ),
      ]),
    );
  }
}
