import 'dart:async';
import 'api/api_exception.dart';
import 'api/demo_backend.dart';

int fails = 0;
void check(String n, bool ok, [Object? extra]) { if (!ok) fails++; print('${ok ? "PASS" : "FAIL"}  $n${ok ? "" : "  -> $extra"}'); }

Future<void> main() async {
  final d = DemoBackend.instance;

  var list = d.nearby(); // الاستدعاء 1
  check('3 طلبات جاهزة', list.length == 3, list.length);
  check('مرتبة بالأقرب أولًا', list.first.id == 1 && list.last.id == 3, list.map((e) => e.id).toList());
  check('طلب 1 فيه أقرب معلم', list.first.dropLandmark == 'بجوار مسجد النور');
  check('الطلب 3 بلا أجرة مقترحة', list.last.suggestedFee == null);

  d.nearby(); // 2
  list = d.nearby(); // 3: يصل الطلب الرابع
  check('وصل طلب رابع في الاستدعاء الثالث', list.length == 4 && list.first.id == 4, list.map((e) => e.id).toList());

  // عرض معقول يُقبل بعد 8 ثوانٍ
  d.submitOffer(freeOrderId: 1, price: 1600, etaMinutes: 15, note: 'جاهز');
  check('العرض يظهر على الطلب كـ my_offer', d.nearby().firstWhere((r) => r.id == 1).myOffer?.price == 1600);
  check('قبل 8 ثوانٍ: لا طلبات حالية', d.currentOrders().isEmpty);

  // عرض مبالغ فيه (> 1.5 ضعف أجرة العميل 2000) لا يُقبل أبدًا
  d.submitOffer(freeOrderId: 2, price: 4000);
  // تعديل العرض الأول (يعيد جدولة القبول)
  d.submitOffer(freeOrderId: 1, price: 1700, etaMinutes: 10);
  check('تعديل العرض لا ينشئ عرضًا ثانيًا', d.myOffers().where((o) => o.freeOrderId == 1).length == 1);

  // سحب عرض
  final offer2 = d.myOffers().firstWhere((o) => o.freeOrderId == 2);
  d.withdrawOffer(offer2.id);
  check('حالة العرض المسحوب', d.myOffers().firstWhere((o) => o.freeOrderId == 2).status == 'withdrawn');
  try { d.withdrawOffer(offer2.id); check('سحب عرض مسحوب يرفض', false); }
  on ApiException catch (e) { check('سحب عرض مسحوب يرفض', e.statusCode == 404, e.statusCode); }

  // عدم التوفر
  d.toggleActive();
  check('بعد التبديل: غير متاح', d.profile().active == false);
  try { d.submitOffer(freeOrderId: 3, price: 1000); check('منع العرض وأنت غير متاح', false); }
  on ApiException catch (e) { check('منع العرض وأنت غير متاح (403)', e.statusCode == 403, e.statusCode); }
  d.toggleActive();
  check('عاد متاحًا', d.profile().active == true);

  print('...انتظار 9 ثوانٍ لقبول العميل التجريبي');
  await Future<void>.delayed(const Duration(seconds: 9));

  final orders = d.currentOrders();
  check('العميل قبل العرض: طلب حالي واحد', orders.length == 1, orders.length);
  final o = orders.first;
  check('رقم الطلب 100001', o.id == 100001, o.id);
  check('أجرة الطلب = سعر العرض المعدّل 1700', o.deliveryCharge == 1700, o.deliveryCharge);
  check('عنوان التسليم يتضمن المعلم', (o.drop.address ?? '').contains('أقرب معلم: بجوار مسجد النور'));
  check('الاستلام من المحل', o.pickup.address == 'كافيه ريزا');
  check('الطلب 1 لم يعد في القريبة', !d.nearby().any((r) => r.id == 1));
  check('العرض 1 صار accepted', d.myOffers().firstWhere((x) => x.freeOrderId == 1).status == 'accepted');
  check('العرض المبالغ فيه (2) لم يُقبل', d.myOffers().firstWhere((x) => x.freeOrderId == 2).status != 'accepted');

  d.updateOrderStatus(o.id, 'picked_up');
  check('بعد الاستلام: isPickedUp', d.currentOrders().first.isPickedUp);
  try { d.updateOrderStatus(o.id, 'delivered', otp: '0000'); check('OTP خاطئ يُرفض', false); }
  on ApiException catch (e) { check('OTP خاطئ يُرفض (406)', e.statusCode == 406, e.statusCode); }
  final before = d.profile();
  d.updateOrderStatus(o.id, 'delivered', otp: '1234');
  final after = d.profile();
  check('بعد التسليم: لا طلبات حالية', d.currentOrders().isEmpty);
  check('زاد عدد الطلبات المكتملة', after.orderCount == before.orderCount + 1, '${before.orderCount}->${after.orderCount}');
  check('زادت أرباح اليوم بقيمة الأجرة', after.todaysEarning == before.todaysEarning + 1700, '${before.todaysEarning}->${after.todaysEarning}');
  try { d.updateOrderStatus(999, 'picked_up'); check('طلب غير موجود', false); }
  on ApiException catch (e) { check('طلب غير موجود (404)', e.statusCode == 404); }

  print('\n${fails == 0 ? "ALL PASSED" : "$fails FAILURES"}');
}
