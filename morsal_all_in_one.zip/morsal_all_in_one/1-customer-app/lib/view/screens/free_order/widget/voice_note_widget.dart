import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:morsal/util/dimensions.dart';
import 'package:morsal/util/styles.dart';
import 'package:morsal/view/base/custom_snackbar.dart';

String _mmss(int seconds) =>
    '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';

/// تسجيل رسالة صوتية: اضغط للبدء، اضغط للإيقاف، ثم استمع أو احذف.
/// يتوقف التسجيل تلقائيًا عند [maxSeconds].
class VoiceRecorderField extends StatefulWidget {
  final String? path;
  final ValueChanged<String?> onChanged;
  final int maxSeconds;
  const VoiceRecorderField({Key? key, required this.path, required this.onChanged, this.maxSeconds = 60}) : super(key: key);

  @override
  State<VoiceRecorderField> createState() => _VoiceRecorderFieldState();
}

class _VoiceRecorderFieldState extends State<VoiceRecorderField> {
  final Record _recorder = Record();
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription? _completeSub;
  Timer? _timer;
  bool _recording = false;
  bool _playing = false;
  int _seconds = 0;

  @override
  void initState() {
    super.initState();
    _completeSub = _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _completeSub?.cancel();
    _player.dispose();
    _recorder.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    try {
      if (!await _recorder.hasPermission()) {
        showCustomSnackBar('free_order_mic_permission'.tr);
        return;
      }
      await _player.stop();
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/free_order_${DateTime.now().millisecondsSinceEpoch}.m4a';
      // جودة منخفضة مناسبة للكلام: ملف صغير يصلح للإنترنت الضعيف
      await _recorder.start(path: path, encoder: AudioEncoder.aacLc, bitRate: 64000, samplingRate: 22050);
      _seconds = 0;
      setState(() { _recording = true; _playing = false; });
      _timer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (!mounted) return;
        setState(() => _seconds++);
        if (_seconds >= widget.maxSeconds) _stop();
      });
    } catch (_) {
      showCustomSnackBar('free_order_mic_error'.tr);
    }
  }

  Future<void> _stop() async {
    _timer?.cancel();
    String? path;
    try {
      path = await _recorder.stop();
    } catch (_) {}
    if (!mounted) return;
    setState(() => _recording = false);
    // نتجاهل الضغطات الخاطئة الأقصر من ثانية
    if (path != null && _seconds >= 1) {
      widget.onChanged(path);
    }
  }

  Future<void> _togglePlay() async {
    if (_playing) {
      await _player.stop();
      setState(() => _playing = false);
      return;
    }
    await _player.play(DeviceFileSource(widget.path!));
    setState(() => _playing = true);
  }

  void _delete() {
    _player.stop();
    setState(() => _playing = false);
    widget.onChanged(null);
  }

  @override
  Widget build(BuildContext context) {
    if (kIsWeb) return const SizedBox(); // التسجيل مدعوم على الجوال فقط
    final Color primary = Theme.of(context).primaryColor;

    Widget child;
    if (_recording) {
      child = Row(children: [
        const Icon(Icons.fiber_manual_record, color: Colors.red, size: 18),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Expanded(child: Text('${'free_order_recording'.tr}  ${_mmss(_seconds)} / ${_mmss(widget.maxSeconds)}', style: robotoMedium)),
        IconButton(onPressed: _stop, icon: const Icon(Icons.stop_circle, color: Colors.red, size: 34), tooltip: 'free_order_stop'.tr),
      ]);
    } else if (widget.path != null) {
      child = Row(children: [
        IconButton(
          onPressed: _togglePlay,
          icon: Icon(_playing ? Icons.pause_circle : Icons.play_circle, color: primary, size: 34),
        ),
        Expanded(child: Text('free_order_voice_ready'.tr, style: robotoMedium)),
        IconButton(onPressed: _delete, icon: const Icon(Icons.delete_outline, color: Colors.red), tooltip: 'delete'.tr),
      ]);
    } else {
      child = InkWell(
        onTap: _start,
        borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
        child: Row(children: [
          CircleAvatar(radius: 20, backgroundColor: primary, child: const Icon(Icons.mic, color: Colors.white)),
          const SizedBox(width: Dimensions.paddingSizeSmall),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('free_order_record_voice'.tr, style: robotoMedium),
            Text('free_order_voice_hint'.tr, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor)),
          ])),
        ]),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall, vertical: Dimensions.paddingSizeExtraSmall),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
        border: Border.all(color: _recording ? Colors.red : primary.withOpacity(0.5)),
      ),
      child: child,
    );
  }
}

/// مشغّل رسالة صوتية من رابط (يُستخدم في شاشة العروض).
class VoicePlayerChip extends StatefulWidget {
  final String url;
  const VoicePlayerChip({Key? key, required this.url}) : super(key: key);

  @override
  State<VoicePlayerChip> createState() => _VoicePlayerChipState();
}

class _VoicePlayerChipState extends State<VoicePlayerChip> {
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription? _completeSub;
  bool _playing = false;

  @override
  void initState() {
    super.initState();
    _completeSub = _player.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _completeSub?.cancel();
    _player.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    try {
      if (_playing) {
        await _player.stop();
        setState(() => _playing = false);
      } else {
        await _player.play(UrlSource(widget.url));
        setState(() => _playing = true);
      }
    } catch (_) {
      showCustomSnackBar('free_order_mic_error'.tr);
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color primary = Theme.of(context).primaryColor;
    return InkWell(
      onTap: _toggle,
      borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: Dimensions.paddingSizeSmall, vertical: Dimensions.paddingSizeExtraSmall),
        decoration: BoxDecoration(color: primary.withOpacity(0.08), borderRadius: BorderRadius.circular(Dimensions.radiusSmall)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(_playing ? Icons.pause_circle : Icons.play_circle, color: primary, size: 30),
          const SizedBox(width: Dimensions.paddingSizeSmall),
          Text('free_order_voice_message'.tr, style: robotoMedium),
        ]),
      ),
    );
  }
}
