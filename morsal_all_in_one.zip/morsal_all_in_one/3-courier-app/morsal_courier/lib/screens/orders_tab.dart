import 'dart:async';

import 'package:flutter/material.dart';

import '../api/api_client.dart';
import '../api/courier_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../services/launcher.dart';
import '../services/session.dart';
import '../widgets/common.dart';
import '../widgets/voice_player.dart';

/// الطلبات المُسندة للمندوب بعد قبول العميل لعرضه: استلام من المحل ثم تسليم.
class OrdersTab extends StatefulWidget {
  const OrdersTab({super.key});

  @override
  State<OrdersTab> createState() => _OrdersTabState();
}

class _OrdersTabState extends State<OrdersTab> {
  List<CourierOrder> _orders = <CourierOrder>[];
  bool _loading = true;
  String? _error;
  Timer? _timer;
  bool _busy = false;
  int? _updatingId;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(kPollInterval, (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (_busy) return;
    _busy = true;
    try {
      final list = await CourierApi.currentOrders();
      if (!mounted) return;
      setState(() {
        _orders = list;
        _error = null;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        if (!silent || _orders.isEmpty) _error = e.message;
        _loading = false;
      });
    } finally {
      _busy = false;
    }
  }

  Future<bool> _confirm(String title, String message) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('لا')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('نعم')),
        ],
      ),
    );
    return ok == true;
  }

  Future<String?> _askOtp() async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('رمز التأكيد'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(kDemoMode
              ? 'رمز التسليم في التجربة: 1234'
              : 'اطلب من العميل الرمز الظاهر في تطبيقه وأدخله هنا'),
          const SizedBox(height: 12),
          TextField(
            controller: controller,
            autofocus: true,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 6,
            decoration: const InputDecoration(border: OutlineInputBorder(), counterText: ''),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(controller.text.trim()),
            child: const Text('تأكيد التسليم'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (result == null || result.isEmpty) return null;
    return result;
  }

  Future<void> _pickedUp(CourierOrder o) async {
    final ok = await _confirm('تأكيد الاستلام', 'هل استلمت الطلب من المحل؟');
    if (ok) await _update(o, 'picked_up');
  }

  Future<void> _delivered(CourierOrder o) async {
    String? otp;
    if (Session.otpRequired) {
      otp = await _askOtp();
      if (otp == null) return;
    } else {
      final ok = await _confirm('تأكيد التسليم', 'هل سلّمت الطلب للعميل؟');
      if (!ok) return;
    }
    await _update(o, 'delivered', otp: otp);
  }

  Future<void> _update(CourierOrder o, String status, {String? otp}) async {
    setState(() => _updatingId = o.id);
    try {
      await CourierApi.updateOrderStatus(o.id, status, otp: otp);
      await _load(silent: true);
      if (!mounted) return;
      showSnack(context, status == 'delivered' ? 'تم تسليم الطلب، شكرًا لك' : 'تم تأكيد الاستلام');
    } on ApiException catch (e) {
      if (!mounted) return;
      showSnack(context, e.statusCode == 406 ? 'رمز التأكيد غير صحيح' : e.message);
    } finally {
      if (mounted) setState(() => _updatingId = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _orders.isEmpty) {
      return ErrorView(message: _error!, onRetry: () => _load());
    }
    return RefreshIndicator(
      onRefresh: () => _load(),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(14),
        children: [
          if (_orders.isEmpty)
            const EmptyState(
              icon: Icons.delivery_dining_outlined,
              text: 'لا توجد طلبات حالية',
              hint: 'عندما يقبل عميل عرضك يظهر طلبه هنا',
            ),
          for (final o in _orders)
            _OrderCard(
              order: o,
              updating: _updatingId == o.id,
              onPickedUp: () => _pickedUp(o),
              onDelivered: () => _delivered(o),
            ),
        ],
      ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final CourierOrder order;
  final bool updating;
  final VoidCallback onPickedUp;
  final VoidCallback onDelivered;
  const _OrderCard({
    required this.order,
    required this.updating,
    required this.onPickedUp,
    required this.onDelivered,
  });

  Widget _point(
    BuildContext context, {
    required IconData icon,
    required String title,
    required OrderPoint point,
    String? phone,
  }) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: scheme.primary),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontSize: 12, color: scheme.outline)),
            Text(point.address ?? 'غير محدد'),
          ]),
        ),
        if (point.hasLocation)
          IconButton(
            tooltip: 'فتح في الخرائط',
            icon: const Icon(Icons.directions),
            onPressed: () => openMap(context, point.lat!, point.lng!),
          ),
        if (phone != null && phone.isNotEmpty)
          IconButton(
            tooltip: 'اتصال',
            icon: const Icon(Icons.call),
            onPressed: () => callPhone(context, phone),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final o = order;
    final scheme = Theme.of(context).colorScheme;
    final pickedUp = o.isPickedUp;
    final voice = o.voiceUrl;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text('طلب #${o.id}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const Spacer(),
            StatusChip(
              pickedUp ? 'في الطريق للعميل' : 'في الطريق للمحل',
              pickedUp ? Colors.blue : scheme.primary,
            ),
          ]),
          if (o.noteText.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(o.noteText),
          ],
          if (voice != null) ...[
            const SizedBox(height: 10),
            Align(alignment: AlignmentDirectional.centerStart, child: VoicePlayerButton(url: voice)),
          ],
          const Divider(height: 24),
          _point(context, icon: Icons.storefront_outlined, title: 'الاستلام من', point: o.pickup),
          _point(
            context,
            icon: Icons.location_on_outlined,
            title: 'التسليم إلى ${o.drop.name ?? o.customerName ?? 'العميل'}',
            point: o.drop,
            phone: o.contactPhone,
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: scheme.primaryContainer,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              'أجرتك: ${money(o.deliveryCharge)}\n'
              'تدفع ثمن المنتجات للمحل من مالك، ثم تحصّل ثمنها مع أجرتك من العميل عند التسليم.',
              style: TextStyle(color: scheme.onPrimaryContainer, fontSize: 13),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: updating ? null : (pickedUp ? onDelivered : onPickedUp),
            icon: updating
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : Icon(pickedUp ? Icons.verified_outlined : Icons.shopping_bag_outlined),
            label: Text(pickedUp ? 'تم التسليم' : 'تم الاستلام من المحل'),
          ),
        ]),
      ),
    );
  }
}
