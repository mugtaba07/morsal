<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('free_orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->index();
            $table->unsignedBigInteger('zone_id')->index();
            $table->unsignedBigInteger('module_id')->nullable();
            $table->text('description');
            $table->string('image')->nullable();
            $table->string('pickup_place_name')->nullable();
            $table->string('pickup_address')->nullable();
            $table->string('pickup_latitude')->nullable();
            $table->string('pickup_longitude')->nullable();
            $table->string('drop_address');
            $table->string('drop_latitude');
            $table->string('drop_longitude');
            $table->string('contact_person_name');
            $table->string('contact_person_number');
            $table->decimal('estimated_item_price', 24, 3)->nullable();
            $table->decimal('suggested_delivery_fee', 24, 3)->nullable();
            $table->string('payment_method')->default('cash_on_delivery');
            // open | accepted | cancelled | expired
            $table->string('status')->default('open')->index();
            $table->unsignedBigInteger('accepted_offer_id')->nullable();
            $table->unsignedBigInteger('order_id')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->timestamps();
        });

        Schema::create('free_order_offers', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('free_order_id')->index();
            $table->unsignedBigInteger('delivery_man_id')->index();
            $table->decimal('price', 24, 3);
            $table->unsignedSmallInteger('eta_minutes')->nullable();
            $table->string('note', 200)->nullable();
            // pending | accepted | rejected | withdrawn
            $table->string('status')->default('pending');
            $table->timestamps();

            // عرض واحد فعّال لكل مندوب على كل طلب
            $table->unique(['free_order_id', 'delivery_man_id']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('free_order_offers');
        Schema::dropIfExists('free_orders');
    }
};
