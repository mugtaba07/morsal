import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../api/api_client.dart';
import '../api/courier_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../services/location_service.dart';
import '../widgets/common.dart';
import 'request_details_screen.dart';

/// الطلبات الحرة المفتوحة في منطقة المندوب، الأقرب أولًا. تتحدث تلقائيًا.
class NearbyTab extends StatefulWidget {
  final bool active;
  const NearbyTab({super.key, required this.active});

  @override
  State<NearbyTab> createState() => _NearbyTabState();
}

class _NearbyTabState extends State<NearbyTab> {
  List<FreeRequest> _items = <FreeRequest>[];
  bool _loading = true;
  String? _error;
  Timer? _timer;
  double? _lat;
  double? _lng;
  bool _busy = false;
  Set<int> _knownIds = <int>{};
  bool _firstLoadDone = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    final pos = await LocationService.current();
    if (pos != null) {
      _lat = pos.latitude;
      _lng = pos.longitude;
    }
    if (!mounted) return;
    await _load();
    if (!mounted) return;
    _timer = Timer.periodic(kPollInterval, (_) => _load(silent: true));
  }

  Future<void> _load({bool silent = false}) async {
    if (_busy) return;
    _busy = true;
    try {
      final list = await CourierApi.nearby(lat: _lat, lng: _lng);
      if (!mounted) return;
      final ids = list.map((e) => e.id).toSet();
      final hasNew = _firstLoadDone && ids.any((id) => !_knownIds.contains(id));
      setState(() {
        _items = list;
        _error = null;
        _loading = false;
      });
      _knownIds = ids;
      _firstLoadDone = true;
      if (hasNew && silent) {
        HapticFeedback.mediumImpact();
        showSnack(context, 'وصل طلب جديد قريب منك');
      }
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        if (!silent || _items.isEmpty) _error = e.message;
        _loading = false;
      });
    } finally {
      _busy = false;
    }
  }

  Future<void> _open(FreeRequest r) async {
    await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(builder: (_) => RequestDetailsScreen(request: r)),
    );
    if (mounted) _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _items.isEmpty) {
      return ErrorView(message: _error!, onRetry: () => _load());
    }
    return RefreshIndicator(
      onRefresh: () => _load(),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(14),
        children: [
          if (!widget.active)
            Card(
              color: Theme.of(context).colorScheme.errorContainer,
              child: const Padding(
                padding: EdgeInsets.all(12),
                child: Text('أنت غير متاح حاليًا. فعّل زر «متاح» في الأعلى لتتمكن من تقديم العروض.'),
              ),
            ),
          if (_items.isEmpty)
            const EmptyState(
              icon: Icons.inbox_outlined,
              text: 'لا توجد طلبات الآن',
              hint: 'سنحدّث القائمة تلقائيًا، وستصلك تنبيه عند وصول طلب جديد',
            ),
          for (final r in _items) _RequestCard(request: r, onTap: () => _open(r)),
        ],
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  final FreeRequest request;
  final VoidCallback onTap;
  const _RequestCard({required this.request, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final r = request;
    final scheme = Theme.of(context).colorScheme;
    final dropText = r.dropLandmark == null ? r.dropAddress : '${r.dropAddress} (${r.dropLandmark})';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              if (r.distanceToPickupKm != null) ...[
                InfoPill(Icons.near_me, '${r.distanceToPickupKm!.toStringAsFixed(1)} كم منك'),
                const SizedBox(width: 6),
              ],
              if (r.tripDistanceKm != null) InfoPill(Icons.route, '${r.tripDistanceKm!.toStringAsFixed(1)} كم رحلة'),
              const Spacer(),
              Text(remainingText(r.remaining), style: TextStyle(fontSize: 12, color: scheme.outline)),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              if (r.hasVoice)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 6),
                  child: Icon(Icons.mic, size: 18, color: scheme.primary),
                ),
              Expanded(
                child: Text(
                  r.description.isEmpty ? 'رسالة صوتية' : r.description,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                ),
              ),
            ]),
            if (r.pickupPlaceName != null) ...[
              const SizedBox(height: 6),
              Row(children: [
                Icon(Icons.storefront_outlined, size: 16, color: scheme.outline),
                const SizedBox(width: 6),
                Expanded(child: Text(r.pickupPlaceName!, style: const TextStyle(fontSize: 13))),
              ]),
            ],
            const SizedBox(height: 4),
            Row(children: [
              Icon(Icons.location_on_outlined, size: 16, color: scheme.outline),
              const SizedBox(width: 6),
              Expanded(child: Text(dropText, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              if (r.suggestedFee != null)
                Text('أجرة العميل: ${money(r.suggestedFee!)}', style: TextStyle(fontSize: 13, color: scheme.primary, fontWeight: FontWeight.w600)),
              const Spacer(),
              if (r.myOffer != null) StatusChip('عرضك: ${money(r.myOffer!.price)}', scheme.primary),
            ]),
          ]),
        ),
      ),
    );
  }
}
