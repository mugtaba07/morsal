#!/usr/bin/env python3
"""يعدّل AndroidManifest.xml الذي ينشئه `flutter create`:
  - يضيف أذونات الإنترنت والموقع (لازمة لتتبع المندوب وتحديد الأقرب)
  - يضبط اسم التطبيق الظاهر على الجوال
  - يسمح بـ HTTP العادي فقط إذا كان عنوان السيرفر يبدأ بـ http://

الاستخدام (من مجلد المشروع بعد flutter create):
    python3 tool/patch_android_manifest.py https://admin.example.com
"""
import re
import sys
from pathlib import Path

MANIFEST = Path("android/app/src/main/AndroidManifest.xml")
APP_LABEL = "مندوب مرسال"
PERMISSIONS = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.ACCESS_COARSE_LOCATION",
]


def main() -> int:
    base_url = sys.argv[1] if len(sys.argv) > 1 else ""
    if not MANIFEST.exists():
        print(f"لم أجد {MANIFEST}. شغّل flutter create أولًا.")
        return 1

    text = MANIFEST.read_text(encoding="utf-8")

    # اسم التطبيق
    text, n = re.subn(r'android:label="[^"]*"', f'android:label="{APP_LABEL}"', text, count=1)

    # HTTP غير المشفّر (غير مستحسن) فقط عند الحاجة
    if base_url.startswith("http://") and "usesCleartextTraffic" not in text:
        text = text.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
        print("تنبيه: تم السماح بـ HTTP غير المشفّر لأن العنوان يبدأ بـ http://. استخدم https للإنتاج.")

    # الأذونات قبل وسم application
    lines = "".join(
        f'    <uses-permission android:name="{p}"/>\n' for p in PERMISSIONS if p not in text
    )
    if lines:
        text = text.replace("<application", lines + "    <application", 1)

    if "<application" not in text:
        print("لم أجد وسم application في الملف.")
        return 1

    MANIFEST.write_text(text, encoding="utf-8")
    print(f"تم تعديل {MANIFEST} (الاسم: {APP_LABEL}).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
