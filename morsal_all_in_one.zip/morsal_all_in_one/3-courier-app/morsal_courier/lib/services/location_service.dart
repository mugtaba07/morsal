import 'dart:async';

import 'package:geolocator/geolocator.dart';

import '../config.dart';

class LocationService {
  /// الموقع الحالي، أو null إذا كانت الخدمة مغلقة أو الإذن مرفوضًا
  static Future<Position?> current() async {
    if (kDemoMode) return null; // التجربة بدون إذن موقع
    try {
      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) return null;

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        return null;
      }
      return await Geolocator.getCurrentPosition().timeout(const Duration(seconds: 15));
    } catch (_) {
      return null;
    }
  }
}
