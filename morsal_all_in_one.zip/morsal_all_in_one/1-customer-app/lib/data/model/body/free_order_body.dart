class FreeOrderBody {
  final String description;
  final String? pickupPlaceName;
  final String? pickupAddress;
  final String? pickupLatitude;
  final String? pickupLongitude;
  final String dropAddress;
  final String? pickupLandmark;
  final String? dropLandmark;
  final String dropLatitude;
  final String dropLongitude;
  final String contactPersonName;
  final String contactPersonNumber;
  final double? estimatedItemPrice;
  final double? suggestedDeliveryFee;
  final String paymentMethod;

  FreeOrderBody({
    required this.description,
    this.pickupPlaceName,
    this.pickupAddress,
    this.pickupLatitude,
    this.pickupLongitude,
    required this.dropAddress,
    this.pickupLandmark,
    this.dropLandmark,
    required this.dropLatitude,
    required this.dropLongitude,
    required this.contactPersonName,
    required this.contactPersonNumber,
    this.estimatedItemPrice,
    this.suggestedDeliveryFee,
    this.paymentMethod = 'cash_on_delivery',
  });

  // الحقول النصية فقط؛ الصورة تُرسل منفصلة كـ multipart
  Map<String, String> toFields() {
    final data = <String, String>{
      'description': description,
      'drop_address': dropAddress,
      'drop_latitude': dropLatitude,
      'drop_longitude': dropLongitude,
      'contact_person_name': contactPersonName,
      'contact_person_number': contactPersonNumber,
      'payment_method': paymentMethod,
    };
    if (pickupLandmark != null && pickupLandmark!.isNotEmpty) data['pickup_landmark'] = pickupLandmark!;
    if (dropLandmark != null && dropLandmark!.isNotEmpty) data['drop_landmark'] = dropLandmark!;
    if (pickupPlaceName != null && pickupPlaceName!.isNotEmpty) data['pickup_place_name'] = pickupPlaceName!;
    if (pickupAddress != null) data['pickup_address'] = pickupAddress!;
    if (pickupLatitude != null) data['pickup_latitude'] = pickupLatitude!;
    if (pickupLongitude != null) data['pickup_longitude'] = pickupLongitude!;
    if (estimatedItemPrice != null) data['estimated_item_price'] = estimatedItemPrice.toString();
    if (suggestedDeliveryFee != null) data['suggested_delivery_fee'] = suggestedDeliveryFee.toString();
    return data;
  }
}
