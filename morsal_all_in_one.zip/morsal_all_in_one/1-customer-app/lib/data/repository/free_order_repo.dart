import 'package:get/get_connect/http/src/response/response.dart';
import 'package:morsal/data/api/api_client.dart';
import 'package:morsal/data/model/body/free_order_body.dart';
import 'package:morsal/util/app_constants.dart';

class FreeOrderRepo {
  final ApiClient apiClient;
  FreeOrderRepo({required this.apiClient});

  Future<Response> placeFreeOrder(FreeOrderBody body, MultipartBody? image, MultipartBody? voice) {
    return apiClient.postMultipartData(
      AppConstants.freeOrderUri, body.toFields(), [if (image != null) image, if (voice != null) voice],
    );
  }

  Future<Response> getEstimate(String pLat, String pLng, String dLat, String dLng) {
    return apiClient.getData('${AppConstants.freeOrderEstimateUri}?pickup_latitude=$pLat&pickup_longitude=$pLng&drop_latitude=$dLat&drop_longitude=$dLng');
  }

  Future<Response> getList(int offset) {
    return apiClient.getData('${AppConstants.freeOrderListUri}?limit=15&offset=$offset');
  }

  Future<Response> getDetails(int id) {
    return apiClient.getData('${AppConstants.freeOrderDetailsUri}?id=$id');
  }

  Future<Response> acceptOffer(int freeOrderId, int offerId) {
    return apiClient.putData(AppConstants.freeOrderAcceptUri, {'free_order_id': freeOrderId, 'offer_id': offerId});
  }

  Future<Response> rejectOffer(int offerId) {
    return apiClient.putData(AppConstants.freeOrderRejectUri, {'offer_id': offerId});
  }

  Future<Response> cancel(int freeOrderId) {
    return apiClient.putData(AppConstants.freeOrderCancelUri, {'free_order_id': freeOrderId});
  }
}
