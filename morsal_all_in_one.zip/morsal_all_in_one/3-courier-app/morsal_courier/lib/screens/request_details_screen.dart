import 'package:flutter/material.dart';

import '../api/api_client.dart';
import '../api/courier_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../services/launcher.dart';
import '../services/session.dart';
import '../widgets/common.dart';
import '../widgets/voice_player.dart';

/// تفاصيل الطلب وتقديم العرض (السعر والوقت وملاحظة)
class RequestDetailsScreen extends StatefulWidget {
  final FreeRequest request;
  const RequestDetailsScreen({super.key, required this.request});

  @override
  State<RequestDetailsScreen> createState() => _RequestDetailsScreenState();
}

class _RequestDetailsScreenState extends State<RequestDetailsScreen> {
  static const List<int> _etaOptions = <int>[10, 15, 20, 30, 45, 60];

  late final TextEditingController _price;
  final TextEditingController _note = TextEditingController();
  int _eta = 20;
  bool _sending = false;

  FreeRequest get r => widget.request;

  @override
  void initState() {
    super.initState();
    final mine = r.myOffer;
    final start = mine != null && mine.isPending ? mine.price : r.suggestedFee;
    _price = TextEditingController(text: start == null ? '' : formatNumber(start).replaceAll(',', ''));
    if (mine != null && mine.isPending && mine.etaMinutes != null) {
      _eta = mine.etaMinutes!;
    }
  }

  @override
  void dispose() {
    _price.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final price = parseNumber(_price.text);
    if (price == null || price <= 0) {
      showSnack(context, 'أدخل سعر التوصيل الذي تقترحه');
      return;
    }
    setState(() => _sending = true);
    try {
      await CourierApi.submitOffer(
        freeOrderId: r.id,
        price: price,
        etaMinutes: _eta,
        note: _note.text.trim(),
      );
      if (!mounted) return;
      showSnack(context, 'تم إرسال عرضك، بانتظار رد العميل');
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      showSnack(context, e.message);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _withdraw() async {
    final mine = r.myOffer;
    if (mine == null) return;
    setState(() => _sending = true);
    try {
      await CourierApi.withdrawOffer(mine.id);
      if (!mounted) return;
      showSnack(context, 'تم سحب عرضك');
      Navigator.of(context).pop(true);
    } on ApiException catch (e) {
      showSnack(context, e.message);
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Widget _section(String title, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
          const SizedBox(height: 10),
          ...children,
        ]),
      ),
    );
  }

  Widget _place({
    required IconData icon,
    required String title,
    required String? name,
    required String? address,
    required String? landmark,
    required double? lat,
    required double? lng,
  }) {
    final lines = <String>[
      if (name != null) name,
      if (address != null && address.isNotEmpty) address,
      if (landmark != null) 'أقرب معلم: $landmark',
    ];
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
            Text(lines.isEmpty ? 'غير محدد' : lines.join('\n')),
          ]),
        ),
        if (lat != null && lng != null)
          IconButton(
            tooltip: 'فتح في الخرائط',
            icon: const Icon(Icons.directions),
            onPressed: () => openMap(context, lat, lng),
          ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final mine = r.myOffer;
    final hasPending = mine != null && mine.isPending;

    return Scaffold(
      appBar: AppBar(title: Text('طلب #${r.id}')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          _section('الطلب', [
            if (r.description.isNotEmpty) Text(r.description, style: const TextStyle(fontSize: 15)),
            if (r.hasVoice) ...[
              const SizedBox(height: 10),
              Align(alignment: AlignmentDirectional.centerStart, child: VoicePlayerButton(url: r.voiceUrl!)),
            ],
            if (r.image != null) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.network(
                  '$kBaseUrl/storage/app/public/order/${r.image}',
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stack) => const SizedBox.shrink(),
                ),
              ),
            ],
            const SizedBox(height: 10),
            Wrap(spacing: 6, runSpacing: 6, children: [
              if (r.distanceToPickupKm != null) InfoPill(Icons.near_me, '${r.distanceToPickupKm!.toStringAsFixed(1)} كم منك'),
              if (r.tripDistanceKm != null) InfoPill(Icons.route, '${r.tripDistanceKm!.toStringAsFixed(1)} كم رحلة'),
              if (r.suggestedFee != null) InfoPill(Icons.payments_outlined, 'أجرة العميل: ${money(r.suggestedFee!)}'),
              if (r.estimatedItemPrice != null) InfoPill(Icons.shopping_bag_outlined, 'المنتجات تقريبًا: ${money(r.estimatedItemPrice!)}'),
            ]),
          ]),
          _section('المسار', [
            _place(
              icon: Icons.storefront_outlined,
              title: 'الشراء من',
              name: r.pickupPlaceName,
              address: r.pickupAddress,
              landmark: r.pickupLandmark,
              lat: r.pickupLat,
              lng: r.pickupLng,
            ),
            _place(
              icon: Icons.location_on_outlined,
              title: 'التسليم إلى${r.customerName == null ? '' : ' (${r.customerName})'}',
              name: null,
              address: r.dropAddress,
              landmark: r.dropLandmark,
              lat: r.dropLat,
              lng: r.dropLng,
            ),
          ]),
          if (hasPending)
            Card(
              color: scheme.primaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text('عرضك الحالي: ${money(mine.price)} — يمكنك تعديله أو سحبه.'),
              ),
            ),
          _section(hasPending ? 'تعديل عرضك' : 'قدّم عرضك', [
            TextField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: InputDecoration(
                labelText: 'سعر التوصيل',
                suffixText: Session.currencySymbol,
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            const Text('وقت الوصول المتوقع للمحل', style: TextStyle(fontSize: 13)),
            const SizedBox(height: 6),
            Wrap(spacing: 8, children: [
              for (final m in _etaOptions)
                ChoiceChip(
                  label: Text('$m د'),
                  selected: _eta == m,
                  onSelected: (_) => setState(() => _eta = m),
                ),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: _note,
              maxLength: 200,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'ملاحظة للعميل (اختياري)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 6),
            FilledButton(
              onPressed: _sending ? null : _send,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: _sending
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(hasPending ? 'تحديث العرض' : 'إرسال العرض', style: const TextStyle(fontSize: 16)),
              ),
            ),
            if (hasPending) ...[
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: _sending ? null : _withdraw,
                child: const Text('سحب العرض'),
              ),
            ],
          ]),
        ],
      ),
    );
  }
}
