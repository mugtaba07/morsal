
import 'dart:convert';

import 'package:morsal/controller/auth_controller.dart';
import 'package:morsal/controller/banner_controller.dart';
import 'package:morsal/controller/booking_checkout_controller.dart';
import 'package:morsal/controller/campaign_controller.dart';
import 'package:morsal/controller/car_selection_controller.dart';
import 'package:morsal/controller/cart_controller.dart';
import 'package:morsal/controller/category_controller.dart';
import 'package:morsal/controller/chat_controller.dart';
import 'package:morsal/controller/coupon_controller.dart';
import 'package:morsal/controller/localization_controller.dart';
import 'package:morsal/controller/location_controller.dart';
import 'package:morsal/controller/notification_controller.dart';
import 'package:morsal/controller/onboarding_controller.dart';
import 'package:morsal/controller/order_controller.dart';
import 'package:morsal/controller/item_controller.dart';
import 'package:morsal/controller/parcel_controller.dart';
import 'package:morsal/controller/free_order_controller.dart';
import 'package:morsal/data/repository/free_order_repo.dart';
import 'package:morsal/controller/rider_controller.dart';
import 'package:morsal/controller/store_controller.dart';
import 'package:morsal/controller/search_controller.dart';
import 'package:morsal/controller/splash_controller.dart';
import 'package:morsal/controller/theme_controller.dart';
import 'package:morsal/controller/user_controller.dart';
import 'package:morsal/controller/wallet_controller.dart';
import 'package:morsal/controller/wishlist_controller.dart';
import 'package:morsal/data/repository/auth_repo.dart';
import 'package:morsal/data/repository/banner_repo.dart';
import 'package:morsal/data/repository/campaign_repo.dart';
import 'package:morsal/data/repository/car_selection_repo.dart';
import 'package:morsal/data/repository/cart_repo.dart';
import 'package:morsal/data/repository/category_repo.dart';
import 'package:morsal/data/repository/coupon_repo.dart';
import 'package:morsal/data/repository/language_repo.dart';
import 'package:morsal/data/repository/location_repo.dart';
import 'package:morsal/data/repository/notification_repo.dart';
import 'package:morsal/data/repository/onboarding_repo.dart';
import 'package:morsal/data/repository/order_repo.dart';
import 'package:morsal/data/repository/item_repo.dart';
import 'package:morsal/data/repository/parcel_repo.dart';
import 'package:morsal/data/repository/rider_repo.dart';
import 'package:morsal/data/repository/store_repo.dart';
import 'package:morsal/data/repository/search_repo.dart';
import 'package:morsal/data/repository/splash_repo.dart';
import 'package:morsal/data/api/api_client.dart';
import 'package:morsal/data/repository/user_repo.dart';
import 'package:morsal/data/repository/wallet_repo.dart';
import 'package:morsal/data/repository/wishlist_repo.dart';
import 'package:morsal/util/app_constants.dart';
import 'package:morsal/data/model/response/language_model.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:get/get.dart';
import '../data/repository/chat_repo.dart';

Future<Map<String, Map<String, String>>> init() async {
  // Core
  final sharedPreferences = await SharedPreferences.getInstance();
  Get.lazyPut(() => sharedPreferences);
  Get.lazyPut(() => ApiClient(appBaseUrl: AppConstants.baseUrl, sharedPreferences: Get.find()));

  // Repository
  Get.lazyPut(() => SplashRepo(sharedPreferences: Get.find(), apiClient: Get.find()));
  Get.lazyPut(() => LanguageRepo());
  Get.lazyPut(() => OnBoardingRepo());
  Get.lazyPut(() => AuthRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => LocationRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => UserRepo(apiClient: Get.find()));
  Get.lazyPut(() => BannerRepo(apiClient: Get.find()));
  Get.lazyPut(() => CategoryRepo(apiClient: Get.find()));
  Get.lazyPut(() => StoreRepo(sharedPreferences: Get.find(), apiClient: Get.find()));
  Get.lazyPut(() => WishListRepo(apiClient: Get.find()));
  Get.lazyPut(() => ItemRepo(apiClient: Get.find()));
  Get.lazyPut(() => CartRepo(sharedPreferences: Get.find()));
  Get.lazyPut(() => SearchRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => CouponRepo(apiClient: Get.find()));
  Get.lazyPut(() => OrderRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => NotificationRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => CampaignRepo(apiClient: Get.find()));
  Get.lazyPut(() => ParcelRepo(apiClient: Get.find()));
  Get.lazyPut(() => FreeOrderRepo(apiClient: Get.find()));
  Get.lazyPut(() => WalletRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => ChatRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => RiderRepo(apiClient: Get.find(), sharedPreferences: Get.find()));
  Get.lazyPut(() => CarSelectionRepo(apiClient: Get.find()));

  // Controller
  Get.lazyPut(() => ThemeController(sharedPreferences: Get.find()));
  Get.lazyPut(() => SplashController(splashRepo: Get.find()));
  Get.lazyPut(() => LocalizationController(sharedPreferences: Get.find(), apiClient: Get.find()));
  Get.lazyPut(() => OnBoardingController(onboardingRepo: Get.find()));
  Get.lazyPut(() => AuthController(authRepo: Get.find()));
  Get.lazyPut(() => LocationController(locationRepo: Get.find()));
  Get.lazyPut(() => UserController(userRepo: Get.find()));
  Get.lazyPut(() => BannerController(bannerRepo: Get.find()));
  Get.lazyPut(() => CategoryController(categoryRepo: Get.find()));
  Get.lazyPut(() => ItemController(itemRepo: Get.find()));
  Get.lazyPut(() => CartController(cartRepo: Get.find()));
  Get.lazyPut(() => StoreController(storeRepo: Get.find()));
  Get.lazyPut(() => WishListController(wishListRepo: Get.find(), itemRepo: Get.find()));
  Get.lazyPut(() => SearchingController(searchRepo: Get.find()));
  Get.lazyPut(() => CouponController(couponRepo: Get.find()));
  Get.lazyPut(() => OrderController(orderRepo: Get.find()));
  Get.lazyPut(() => NotificationController(notificationRepo: Get.find()));
  Get.lazyPut(() => CampaignController(campaignRepo: Get.find()));
  Get.lazyPut(() => ParcelController(parcelRepo: Get.find()));
  Get.lazyPut(() => FreeOrderController(freeOrderRepo: Get.find()));
  Get.lazyPut(() => WalletController(walletRepo: Get.find()));
  Get.lazyPut(() => ChatController(chatRepo: Get.find()));
  Get.lazyPut(() => RiderController(riderRepo: Get.find()));
  Get.lazyPut(() => CarSelectionController(carSelectionRepo: Get.find()));
  Get.lazyPut(() => BookingCheckoutController(riderRepo: Get.find()));

  // Retrieving localized data
  Map<String, Map<String, String>> languages = {};
  for(LanguageModel languageModel in AppConstants.languages) {
    String jsonStringValues =  await rootBundle.loadString('assets/language/${languageModel.languageCode}.json');
    Map<String, dynamic> mappedJson = jsonDecode(jsonStringValues);
    Map<String, String> json = {};
    mappedJson.forEach((key, value) {
      json[key] = value.toString();
    });
    languages['${languageModel.languageCode}_${languageModel.countryCode}'] = json;
  }
  return languages;
}
