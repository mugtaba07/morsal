import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:morsal/controller/auth_controller.dart';
import 'package:morsal/controller/free_order_controller.dart';
import 'package:morsal/data/model/response/free_order_model.dart';
import 'package:morsal/helper/date_converter.dart';
import 'package:morsal/helper/route_helper.dart';
import 'package:morsal/util/dimensions.dart';
import 'package:morsal/util/styles.dart';
import 'package:morsal/view/base/custom_app_bar.dart';
import 'package:morsal/view/base/custom_button.dart';

/// قائمة طلباتي الحرة: الحالة وعدد العروض، والضغط يفتح العروض أو تتبع الطلب.
class FreeOrderListScreen extends StatefulWidget {
  const FreeOrderListScreen({Key? key}) : super(key: key);

  @override
  State<FreeOrderListScreen> createState() => _FreeOrderListScreenState();
}

class _FreeOrderListScreenState extends State<FreeOrderListScreen> {
  final ScrollController _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    if (Get.find<AuthController>().isLoggedIn()) {
      Get.find<FreeOrderController>().loadMyRequests();
    }
    // تحميل الصفحة التالية قرب نهاية القائمة
    _scroll.addListener(() {
      if (_scroll.position.pixels >= _scroll.position.maxScrollExtent - 200) {
        Get.find<FreeOrderController>().loadMyRequests(reload: false);
      }
    });
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _open(FreeOrderModel o) async {
    if (o.isAccepted && o.orderId != null) {
      await Get.toNamed(RouteHelper.getOrderDetailsRoute(o.orderId));
    } else {
      await Get.toNamed(RouteHelper.getFreeOrderOffersRoute(o.id!));
    }
    // تحديث الحالة بعد الرجوع (قد يكون الطلب قُبل أو أُلغي)
    Get.find<FreeOrderController>().loadMyRequests();
  }

  _StatusStyle _status(BuildContext context, FreeOrderModel o) {
    switch (o.status) {
      case 'open':
        return _StatusStyle('free_order_status_open'.tr, Theme.of(context).primaryColor);
      case 'accepted':
        return _StatusStyle('free_order_status_accepted'.tr, Colors.blue);
      case 'expired':
        return _StatusStyle('free_order_status_expired'.tr, Theme.of(context).disabledColor);
      default:
        return _StatusStyle('free_order_status_cancelled'.tr, Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'my_free_orders'.tr),
      body: SafeArea(
        child: !Get.find<AuthController>().isLoggedIn()
          ? Center(child: Text('you_are_not_logged_in'.tr, style: robotoMedium))
          : GetBuilder<FreeOrderController>(builder: (c) {
              if (c.isListLoading) return const Center(child: CircularProgressIndicator());
              if (c.myRequests.isEmpty) return _empty(context);

              return RefreshIndicator(
                onRefresh: () => c.loadMyRequests(),
                child: ListView.builder(
                  controller: _scroll,
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
                  itemCount: c.myRequests.length + (c.isListLoadingMore ? 1 : 0),
                  itemBuilder: (context, i) {
                    if (i >= c.myRequests.length) {
                      return const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator()));
                    }
                    return _card(context, c.myRequests[i]);
                  },
                ),
              );
            }),
      ),
    );
  }

  Widget _empty(BuildContext context) {
    return ListView(children: [
      const SizedBox(height: 120),
      Icon(Icons.edit_note, size: 64, color: Theme.of(context).disabledColor),
      const SizedBox(height: Dimensions.paddingSizeDefault),
      Center(child: Text('free_order_list_empty'.tr, style: robotoMedium.copyWith(color: Theme.of(context).disabledColor))),
      CustomButton(
        margin: const EdgeInsets.all(Dimensions.paddingSizeLarge),
        buttonText: 'free_order_new_request'.tr,
        onPressed: () => Get.offNamed(RouteHelper.getFreeOrderRoute()),
      ),
    ]);
  }

  Widget _card(BuildContext context, FreeOrderModel o) {
    final st = _status(context, o);
    final bool hasText = (o.description ?? '').isNotEmpty;
    final int offers = o.pendingOffersCount ?? 0;

    return InkWell(
      onTap: () => _open(o),
      borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
      child: Container(
        margin: const EdgeInsets.only(bottom: Dimensions.paddingSizeSmall),
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(Dimensions.radiusDefault),
          border: Border.all(color: Theme.of(context).disabledColor.withOpacity(0.4)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(color: st.color.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
              child: Text(st.text, style: robotoMedium.copyWith(color: st.color, fontSize: Dimensions.fontSizeSmall)),
            ),
            const Spacer(),
            if (o.createdAt != null) Text(DateConverter.dateToDateAndTimeAm(o.createdAt!),
                style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).disabledColor)),
          ]),
          const SizedBox(height: Dimensions.paddingSizeSmall),
          Row(children: [
            if ((o.voiceUrl ?? '').isNotEmpty) Padding(
              padding: const EdgeInsetsDirectional.only(end: 6),
              child: Icon(Icons.mic, size: 18, color: Theme.of(context).primaryColor),
            ),
            Expanded(child: Text(
              hasText ? o.description! : 'free_order_voice_message'.tr,
              maxLines: 2, overflow: TextOverflow.ellipsis, style: robotoMedium,
            )),
          ]),
          if ((o.pickupPlaceName ?? '').isNotEmpty) Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(o.pickupPlaceName!, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor)),
          ),
          if (o.isOpen && offers > 0) Padding(
            padding: const EdgeInsets.only(top: Dimensions.paddingSizeSmall),
            child: Row(children: [
              Icon(Icons.local_offer_outlined, size: 16, color: Theme.of(context).primaryColor),
              const SizedBox(width: 4),
              Text('$offers ${'free_order_offers_count'.tr}', style: robotoMedium.copyWith(color: Theme.of(context).primaryColor, fontSize: Dimensions.fontSizeSmall)),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _StatusStyle {
  final String text;
  final Color color;
  _StatusStyle(this.text, this.color);
}
