import '../models/models.dart';
import 'api_exception.dart';

/// خادم وهمي في الذاكرة لتجربة التطبيق بدون سيرفر (--dart-define=DEMO=true).
///
/// سلوك التجربة:
///  - 3 طلبات جاهزة، ويصل رابع بعد حوالي 20 ثانية لتجربة تنبيه الطلب الجديد.
///  - العميل التجريبي يقبل عرضك بعد 8 ثوانٍ إذا لم يتجاوز سعرك 1.5 ضعف أجرته المقترحة،
///    وإلا يبقى عرضك «بانتظار الرد» لتجرب السحب أو التعديل.
///  - رمز التسليم في التجربة: 1234
class DemoBackend {
  DemoBackend._();
  static final DemoBackend instance = DemoBackend._();

  static const String demoOtp = '1234';
  static const int acceptAfterSeconds = 8;
  static const double acceptFactor = 1.5;

  bool _active = true;
  int _nearbyCalls = 0;
  bool _extraAdded = false;
  int _nextOfferId = 1;
  int _completed = 12;
  double _todayEarning = 4500;

  final List<Map<String, dynamic>> _requests = <Map<String, dynamic>>[
    _request(1, 'قهوة لاتيه كبيرة وكرواسون جبن', 'كافيه ريزا', 'الخرطوم، حي الرياض، شارع 15',
        landmark: 'بجوار مسجد النور', price: 4500, fee: 1500, dist: 1.2, trip: 3.4, customer: 'أحمد'),
    _request(2, 'علبة بنادول وكمامات من الصيدلية', 'صيدلية النيل', 'أم درمان، حي الملازمين',
        landmark: 'خلف المدرسة', price: 3000, fee: 2000, dist: 3.8, trip: 6.1, customer: 'مريم'),
    _request(3, 'شاورما دجاج عدد 2 مع بطاطس', 'مطعم الأصيل', 'بحري، الدناقلة',
        price: 7000, dist: 5.0, trip: 4.2, customer: 'عمر'),
  ];
  final List<Map<String, dynamic>> _offers = <Map<String, dynamic>>[];
  final List<Map<String, dynamic>> _orders = <Map<String, dynamic>>[];

  static Map<String, dynamic> _request(
    int id,
    String description,
    String place,
    String drop, {
    String? landmark,
    double? price,
    double? fee,
    required double dist,
    required double trip,
    required String customer,
  }) {
    return <String, dynamic>{
      'id': id,
      'description': description,
      'image': null,
      'voice_url': null,
      'pickup_place_name': place,
      'pickup_address': null,
      'pickup_landmark': null,
      'pickup_latitude': '15.5007',
      'pickup_longitude': '32.5599',
      'drop_address': drop,
      'drop_landmark': landmark,
      'drop_latitude': '15.52',
      'drop_longitude': '32.58',
      'estimated_item_price': price,
      'suggested_delivery_fee': fee,
      'status': 'open',
      'expires_at': DateTime.now().add(const Duration(minutes: 28)).toUtc().toIso8601String(),
      'distance_to_pickup_km': dist,
      'trip_distance_km': trip,
      'customer_name': customer,
    };
  }

  /// يحوّل العروض التي حان وقت قبولها إلى طلبات مُسندة للمندوب
  void _tick() {
    final now = DateTime.now();
    for (final o in _offers) {
      final at = o['accept_at'];
      if (o['status'] == 'pending' && at is DateTime && now.isAfter(at)) {
        final matches = _requests.where((r) => r['id'] == o['free_order_id'] && r['status'] == 'open');
        if (matches.isEmpty) continue;
        final req = matches.first;
        o['status'] = 'accepted';
        req['status'] = 'accepted';
        final orderId = 100000 + (req['id'] as int);
        req['order_id'] = orderId;
        final dropAddress = req['drop_landmark'] == null
            ? req['drop_address']
            : '${req['drop_address']} (أقرب معلم: ${req['drop_landmark']})';
        _orders.add(<String, dynamic>{
          'id': orderId,
          'order_status': 'accepted',
          'order_note': req['description'],
          'delivery_charge': o['price'],
          'payment_method': 'cash_on_delivery',
          'delivery_address': <String, dynamic>{
            'contact_person_name': req['customer_name'],
            'contact_person_number': '+249911111111',
            'address': req['pickup_place_name'],
            'latitude': req['pickup_latitude'],
            'longitude': req['pickup_longitude'],
          },
          'receiver_details': <String, dynamic>{
            'contact_person_name': req['customer_name'],
            'contact_person_number': '+249911111111',
            'address': dropAddress,
            'latitude': req['drop_latitude'],
            'longitude': req['drop_longitude'],
          },
          'customer': <String, dynamic>{
            'f_name': req['customer_name'],
            'l_name': '',
            'phone': '+249911111111',
          },
        });
      }
    }
  }

  CourierProfile profile() {
    return CourierProfile.fromJson(<String, dynamic>{
      'f_name': 'خالد',
      'l_name': 'العتيبي',
      'phone': '+249912345678',
      'active': _active ? 1 : 0,
      'avg_rating': 4.8,
      'rating_count': 37,
      'order_count': _completed,
      'current_orders': _orders.length,
      'todays_earning': _todayEarning,
      'this_week_earning': 18500 + _todayEarning,
      'this_month_earning': 74000 + _todayEarning,
      'cash_in_hands': 6000,
      'balance': 12500,
    });
  }

  void toggleActive() {
    _active = !_active;
  }

  List<FreeRequest> nearby() {
    _nearbyCalls++;
    if (_nearbyCalls == 3 && !_extraAdded) {
      _extraAdded = true;
      _requests.add(_request(4, 'خبز طازج عدد 10 حبات', 'مخبز السلام', 'الخرطوم 2، شارع المشتل',
          fee: 1000, price: 1500, dist: 0.9, trip: 1.8, customer: 'سارة'));
    }
    _tick();
    final list = <FreeRequest>[];
    for (final r in _requests) {
      if (r['status'] != 'open') continue;
      final json = Map<String, dynamic>.from(r);
      final mine = _offers.where((o) => o['free_order_id'] == r['id'] && o['status'] == 'pending');
      if (mine.isNotEmpty) {
        final o = mine.first;
        json['my_offer'] = <String, dynamic>{
          'id': o['id'],
          'price': o['price'],
          'eta_minutes': o['eta_minutes'],
          'status': o['status'],
        };
      }
      list.add(FreeRequest.fromJson(json));
    }
    list.sort((a, b) => (a.distanceToPickupKm ?? 99).compareTo(b.distanceToPickupKm ?? 99));
    return list;
  }

  void submitOffer({required int freeOrderId, required double price, int? etaMinutes, String? note}) {
    if (!_active) {
      throw const ApiException('أنت غير متاح حاليًا، فعّل حالتك أولًا', statusCode: 403);
    }
    _tick();
    final matches = _requests.where((r) => r['id'] == freeOrderId && r['status'] == 'open');
    if (matches.isEmpty) {
      throw const ApiException('هذا الطلب لم يعد متاحًا', statusCode: 404);
    }
    final req = matches.first;
    final fee = req['suggested_delivery_fee'];
    final willAccept = fee is! num || price <= fee.toDouble() * acceptFactor;
    final acceptAt = willAccept ? DateTime.now().add(const Duration(seconds: acceptAfterSeconds)) : null;

    final existing = _offers.where((o) => o['free_order_id'] == freeOrderId);
    if (existing.isNotEmpty) {
      final o = existing.first;
      o['price'] = price;
      o['eta_minutes'] = etaMinutes;
      o['note'] = note;
      o['status'] = 'pending';
      o['accept_at'] = acceptAt;
    } else {
      _offers.add(<String, dynamic>{
        'id': _nextOfferId++,
        'free_order_id': freeOrderId,
        'price': price,
        'eta_minutes': etaMinutes,
        'note': note,
        'status': 'pending',
        'accept_at': acceptAt,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    }
  }

  void withdrawOffer(int offerId) {
    final matches = _offers.where((o) => o['id'] == offerId && o['status'] == 'pending');
    if (matches.isEmpty) {
      throw const ApiException('هذا العرض لم يعد متاحًا', statusCode: 404);
    }
    // نحفظ العنصر أولًا: matches قائمة مفلترة كسولة، وبعد تغيير الحالة لن تطابق الفلتر
    final offer = matches.first;
    offer['status'] = 'withdrawn';
    offer['accept_at'] = null;
  }

  List<OfferItem> myOffers() {
    _tick();
    final items = <OfferItem>[];
    for (final o in _offers.reversed) {
      final req = _requests.firstWhere((r) => r['id'] == o['free_order_id']);
      items.add(OfferItem.fromJson(<String, dynamic>{
        'id': o['id'],
        'free_order_id': o['free_order_id'],
        'price': o['price'],
        'eta_minutes': o['eta_minutes'],
        'note': o['note'],
        'status': o['status'],
        'created_at': o['created_at'],
        'free_order': <String, dynamic>{
          'id': req['id'],
          'description': req['description'],
          'status': req['status'],
          'order_id': req['order_id'],
        },
      }));
    }
    return items;
  }

  List<CourierOrder> currentOrders() {
    _tick();
    return _orders.map((o) => CourierOrder.fromJson(Map<String, dynamic>.from(o))).toList();
  }

  void updateOrderStatus(int orderId, String status, {String? otp}) {
    final matches = _orders.where((o) => o['id'] == orderId);
    if (matches.isEmpty) {
      throw const ApiException('الطلب غير موجود', statusCode: 404);
    }
    final order = matches.first;
    if (status == 'picked_up') {
      order['order_status'] = 'picked_up';
    } else if (status == 'delivered') {
      if (otp != demoOtp) {
        throw const ApiException('Not matched', statusCode: 406);
      }
      _completed++;
      _todayEarning += (order['delivery_charge'] as num).toDouble();
      _orders.remove(order);
    }
  }
}
