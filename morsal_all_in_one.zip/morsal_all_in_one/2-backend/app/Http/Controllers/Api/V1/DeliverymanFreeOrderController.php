<?php

namespace App\Http\Controllers\Api\V1;

use App\CentralLogics\FreeOrderLogic;
use App\CentralLogics\Helpers;
use App\Http\Controllers\Controller;
use App\Models\DeliveryMan;
use App\Models\FreeOrder;
use App\Models\FreeOrderOffer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
 * الطلب الحر - جهة المندوب: استعراض الطلبات القريبة وتقديم/سحب العروض.
 * جميع المسارات خلف ميدلوير dm.api (توكن المندوب في الحقل token).
 */
class DeliverymanFreeOrderController extends Controller
{
    private function error($code, $message, $status = 403)
    {
        return response()->json(['errors' => [['code' => $code, 'message' => $message]]], $status);
    }

    private function dm(Request $request)
    {
        return DeliveryMan::where('auth_token', $request['token'])->first();
    }

    private function canBid(DeliveryMan $dm)
    {
        return $dm->active && $dm->application_status === 'approved';
    }

    // GET delivery-man/free-order/nearby?latitude=&longitude=&radius_km=
    public function nearby(Request $request)
    {
        $dm = $this->dm($request);
        FreeOrder::expireStale();

        $lat = $request->latitude;
        $lng = $request->longitude;
        $radius = $request->radius_km ? (float)$request->radius_km : null;

        $requests = FreeOrder::open()
            ->where('zone_id', $dm->zone_id)
            ->latest()
            ->limit(50)
            ->get();

        // عروضي الحالية على هذه الطلبات
        $my_offers = FreeOrderOffer::where('delivery_man_id', $dm->id)
            ->whereIn('free_order_id', $requests->pluck('id'))
            ->get()->keyBy('free_order_id');

        $rows = $requests->map(function ($fo) use ($lat, $lng, $my_offers) {
            $row = FreeOrderLogic::format_request($fo, $lat, $lng);
            $mine = $my_offers->get($fo->id);
            $row['my_offer'] = $mine ? [
                'id' => $mine->id,
                'price' => $mine->price,
                'eta_minutes' => $mine->eta_minutes,
                'status' => $mine->status,
            ] : null;
            $row['customer_name'] = $fo->customer ? $fo->customer->f_name : null; // الاسم الأول فقط
            return $row;
        });

        if ($radius !== null && $lat && $lng) {
            $rows = $rows->filter(function ($r) use ($radius) {
                return $r['distance_to_pickup_km'] === null || $r['distance_to_pickup_km'] <= $radius;
            });
        }
        if ($lat && $lng) {
            $rows = $rows->sortBy(function ($r) {
                return $r['distance_to_pickup_km'] ?? PHP_INT_MAX;
            });
        }

        return response()->json($rows->values(), 200);
    }

    // POST delivery-man/free-order/offer  {free_order_id, price, eta_minutes?, note?}
    public function submit_offer(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'free_order_id' => 'required|integer|exists:free_orders,id',
            'price' => 'required|numeric|min:0.01',
            'eta_minutes' => 'nullable|integer|min:1|max:480',
            'note' => 'nullable|string|max:200',
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }

        $dm = $this->dm($request);
        if (!$this->canBid($dm)) {
            return $this->error('dm_unavailable', translate('messages.dm_unavailable'));
        }
        if ($dm->current_orders >= config('dm_maximum_orders')) {
            return $this->error('dm_maximum_order_exceed', translate('messages.dm_maximum_order_exceed_warning'), 405);
        }

        $fo = FreeOrder::open()->where('id', $request->free_order_id)->where('zone_id', $dm->zone_id)->first();
        if (!$fo) {
            return $this->error('free_order_closed', translate('messages.free_order_closed'), 404);
        }

        $existing = FreeOrderOffer::where('free_order_id', $fo->id)->where('delivery_man_id', $dm->id)->first();
        if ($existing && $existing->status === 'accepted') {
            return $this->error('offer', translate('messages.offer_not_available'));
        }

        // إنشاء العرض أو تحديثه (يُعاد إلى pending عند التعديل)
        $offer = FreeOrderOffer::updateOrCreate(
            ['free_order_id' => $fo->id, 'delivery_man_id' => $dm->id],
            [
                'price' => $request->price,
                'eta_minutes' => $request->eta_minutes,
                'note' => $request->note,
                'status' => 'pending',
            ]
        );

        if ($fo->customer) {
            FreeOrderLogic::push(
                $fo->customer->cm_firebase_token,
                translate('messages.new_offer_title'),
                trim($dm->f_name . ' ' . $dm->l_name) . ': ' . $offer->price,
                $fo->id,
                'free_order_offer'
            );
        }

        return response()->json(['message' => translate('messages.offer_sent'), 'offer_id' => $offer->id], 200);
    }

    // PUT delivery-man/free-order/withdraw-offer  {offer_id}
    public function withdraw_offer(Request $request)
    {
        $validator = Validator::make($request->all(), ['offer_id' => 'required|integer']);
        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }
        $dm = $this->dm($request);
        $offer = FreeOrderOffer::where('id', $request->offer_id)
            ->where('delivery_man_id', $dm->id)
            ->where('status', 'pending')
            ->first();
        if (!$offer) {
            return $this->error('offer', translate('messages.offer_not_available'), 404);
        }
        $offer->status = 'withdrawn';
        $offer->save();
        return response()->json(['message' => translate('messages.updated_successfully')], 200);
    }

    // GET delivery-man/free-order/my-offers
    public function my_offers(Request $request)
    {
        $dm = $this->dm($request);
        $offers = FreeOrderOffer::with('freeOrder')
            ->where('delivery_man_id', $dm->id)
            ->latest()
            ->limit(50)
            ->get()
            ->map(function ($offer) {
                $row = FreeOrderLogic::format_offer($offer);
                $row['free_order'] = $offer->freeOrder ? [
                    'id' => $offer->freeOrder->id,
                    'description' => $offer->freeOrder->description,
                    'status' => $offer->freeOrder->status,
                    'order_id' => $offer->freeOrder->order_id,
                ] : null;
                return $row;
            });
        return response()->json($offers, 200);
    }
}
