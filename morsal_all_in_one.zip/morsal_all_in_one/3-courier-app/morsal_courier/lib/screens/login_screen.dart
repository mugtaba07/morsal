import 'package:flutter/material.dart';

import '../api/api_client.dart';
import '../api/courier_api.dart';
import '../config.dart';
import '../services/session.dart';
import 'home_shell.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _phone = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool _loading = false;
  bool _obscure = true;
  String? _error;

  @override
  void dispose() {
    _phone.dispose();
    _password.dispose();
    super.dispose();
  }

  /// يقبل 0912345678 أو 912345678 أو 249912345678 أو +249912345678
  String _normalizePhone(String input) {
    const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
    final buf = StringBuffer();
    for (final ch in input.trim().split('')) {
      final i = arabicDigits.indexOf(ch);
      if (i >= 0) {
        buf.write(i);
      } else if (ch != ' ' && ch != '-') {
        buf.write(ch);
      }
    }
    final p = buf.toString();
    final code = kDefaultCountryCode; // مثل +249
    final codeDigits = code.substring(1);
    if (p.startsWith('+')) return p;
    if (p.startsWith('00')) return '+${p.substring(2)}';
    if (p.startsWith(codeDigits)) return '+$p';
    if (p.startsWith('0')) return '$code${p.substring(1)}';
    return '$code$p';
  }

  Future<void> _submit() async {
    final phone = _normalizePhone(_phone.text);
    final password = _password.text;
    if (_phone.text.trim().isEmpty || password.isEmpty) {
      setState(() => _error = 'أدخل رقم الهاتف وكلمة المرور');
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final token = await CourierApi.login(phone, password);
      await Session.saveToken(token);
      try {
        await CourierApi.refreshConfig();
      } catch (_) {
        // الإعدادات اختيارية: نكمل بالقيم الافتراضية
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => const HomeShell()),
      );
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.delivery_dining, size: 76, color: scheme.primary),
                  const SizedBox(height: 12),
                  const Text(
                    'مندوب مرسال',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'سجّل دخولك لاستقبال الطلبات',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: scheme.outline),
                  ),
                  const SizedBox(height: 28),
                  TextField(
                    controller: _phone,
                    keyboardType: TextInputType.phone,
                    textDirection: TextDirection.ltr,
                    textInputAction: TextInputAction.next,
                    decoration: const InputDecoration(
                      labelText: 'رقم الهاتف',
                      hintText: '0912345678',
                      prefixIcon: Icon(Icons.phone_outlined),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _password,
                    obscureText: _obscure,
                    onSubmitted: (_) => _submit(),
                    decoration: InputDecoration(
                      labelText: 'كلمة المرور',
                      prefixIcon: const Icon(Icons.lock_outline),
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        icon: Icon(_obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                        onPressed: () => setState(() => _obscure = !_obscure),
                      ),
                    ),
                  ),
                  if (_error != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: scheme.error)),
                    ),
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: _loading ? null : _submit,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: _loading
                          ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Text('تسجيل الدخول', style: TextStyle(fontSize: 16)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  if (kDemoMode)
                    Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: scheme.tertiaryContainer,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        'وضع تجريبي بدون خادم: اكتب أي رقم وأي كلمة مرور',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: scheme.onTertiaryContainer),
                      ),
                    ),
                  Text(
                    'حساب المندوب يُفعَّل من إدارة التطبيق',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: scheme.outline, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
