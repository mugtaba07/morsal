import 'dart:async';

import 'package:flutter/material.dart';

import '../api/api_client.dart';
import '../api/courier_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../widgets/common.dart';

/// العروض التي قدّمها المندوب وحالتها.
class OffersTab extends StatefulWidget {
  const OffersTab({super.key});

  @override
  State<OffersTab> createState() => _OffersTabState();
}

class _OffersTabState extends State<OffersTab> {
  List<OfferItem> _items = <OfferItem>[];
  bool _loading = true;
  String? _error;
  Timer? _timer;
  bool _busy = false;
  int? _withdrawingId;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(kPollInterval, (_) => _load(silent: true));
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (_busy) return;
    _busy = true;
    try {
      final list = await CourierApi.myOffers();
      if (!mounted) return;
      setState(() {
        _items = list;
        _error = null;
        _loading = false;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        if (!silent || _items.isEmpty) _error = e.message;
        _loading = false;
      });
    } finally {
      _busy = false;
    }
  }

  Future<void> _withdraw(OfferItem o) async {
    setState(() => _withdrawingId = o.id);
    try {
      await CourierApi.withdrawOffer(o.id);
      await _load(silent: true);
      if (mounted) showSnack(context, 'تم سحب العرض');
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message);
    } finally {
      if (mounted) setState(() => _withdrawingId = null);
    }
  }

  (String, Color) _statusStyle(OfferItem o) {
    switch (o.status) {
      case 'accepted':
        return ('تم قبول عرضك', Colors.green.shade700);
      case 'rejected':
        return ('لم يُقبل', Colors.red.shade400);
      case 'withdrawn':
        return ('مسحوب', Colors.grey);
      default:
        return ('بانتظار رد العميل', Colors.orange.shade700);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null && _items.isEmpty) {
      return ErrorView(message: _error!, onRetry: () => _load());
    }
    final scheme = Theme.of(context).colorScheme;
    return RefreshIndicator(
      onRefresh: () => _load(),
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(14),
        children: [
          if (_items.isEmpty)
            const EmptyState(
              icon: Icons.local_offer_outlined,
              text: 'لم تقدّم أي عرض بعد',
              hint: 'افتح تبويب «القريبة» وقدّم عرضك على أي طلب',
            ),
          for (final o in _items)
            Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text(money(o.price), style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: scheme.primary)),
                    if (o.etaMinutes != null) ...[
                      const SizedBox(width: 10),
                      Text('${o.etaMinutes} د', style: TextStyle(color: scheme.outline)),
                    ],
                    const Spacer(),
                    StatusChip(_statusStyle(o).$1, _statusStyle(o).$2),
                  ]),
                  const SizedBox(height: 8),
                  Text(
                    o.requestDescription.isEmpty ? 'رسالة صوتية' : o.requestDescription,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (o.note != null) ...[
                    const SizedBox(height: 6),
                    Text('ملاحظتك: ${o.note}', style: TextStyle(fontSize: 12, color: scheme.outline)),
                  ],
                  if (o.status == 'accepted') ...[
                    const SizedBox(height: 8),
                    Text('تابع الطلب من تبويب «طلباتي».', style: TextStyle(fontSize: 13, color: Colors.green.shade700)),
                  ],
                  if (o.isPending) ...[
                    const SizedBox(height: 8),
                    Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: TextButton(
                        onPressed: _withdrawingId == o.id ? null : () => _withdraw(o),
                        child: const Text('سحب العرض'),
                      ),
                    ),
                  ],
                ]),
              ),
            ),
        ],
      ),
    );
  }
}
