import 'package:flutter/material.dart';

import '../config.dart';
import '../models/models.dart';
import '../services/session.dart';
import '../widgets/common.dart';
import 'login_screen.dart';

class ProfileTab extends StatelessWidget {
  final CourierProfile? profile;
  final Future<void> Function() onRefresh;
  final VoidCallback onToggleActive;
  final bool toggling;

  const ProfileTab({
    super.key,
    required this.profile,
    required this.onRefresh,
    required this.onToggleActive,
    required this.toggling,
  });

  Future<void> _logout(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('هل تريد تسجيل الخروج من الحساب؟'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('خروج')),
        ],
      ),
    );
    if (ok != true) return;
    await Session.clear();
    if (!context.mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  Widget _stat(BuildContext context, String label, String value, {IconData? icon}) {
    final scheme = Theme.of(context).colorScheme;
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          child: Column(children: [
            if (icon != null) Icon(icon, color: scheme.primary, size: 22),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15), textAlign: TextAlign.center),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 12, color: scheme.outline), textAlign: TextAlign.center),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = profile;
    final scheme = Theme.of(context).colorScheme;
    if (p == null) return const Center(child: CircularProgressIndicator());

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(14),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: scheme.primaryContainer,
                  child: Text(
                    p.name.isEmpty ? '?' : p.name.substring(0, 1),
                    style: TextStyle(fontSize: 22, color: scheme.onPrimaryContainer),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                    Text(p.phone, textDirection: TextDirection.ltr, style: TextStyle(color: scheme.outline)),
                    const SizedBox(height: 4),
                    Row(children: [
                      const Icon(Icons.star, size: 16, color: Colors.amber),
                      const SizedBox(width: 4),
                      Text(p.rating == null ? 'لا تقييم بعد' : '${p.rating!.toStringAsFixed(1)} (${p.ratingCount})'),
                    ]),
                  ]),
                ),
              ]),
            ),
          ),
          Card(
            child: SwitchListTile(
              title: const Text('متاح لاستقبال الطلبات'),
              subtitle: const Text('عند الإيقاف لن تتمكن من تقديم عروض جديدة'),
              value: p.active,
              onChanged: toggling ? null : (_) => onToggleActive(),
            ),
          ),
          Row(children: [
            _stat(context, 'طلباتك المكتملة', '${p.orderCount}', icon: Icons.check_circle_outline),
            _stat(context, 'طلبات جارية', '${p.currentOrders}', icon: Icons.delivery_dining_outlined),
          ]),
          Row(children: [
            _stat(context, 'اليوم', money(p.todaysEarning)),
            _stat(context, 'هذا الأسبوع', money(p.weekEarning)),
            _stat(context, 'هذا الشهر', money(p.monthEarning)),
          ]),
          Row(children: [
            _stat(context, 'كاش بحوزتك', money(p.cashInHands), icon: Icons.account_balance_wallet_outlined),
            _stat(context, 'رصيدك', money(p.balance), icon: Icons.savings_outlined),
          ]),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => _logout(context),
            icon: const Icon(Icons.logout),
            label: const Text('تسجيل الخروج'),
          ),
          const SizedBox(height: 16),
          Text(
            kDemoMode ? 'وضع تجريبي (بيانات وهمية)' : 'الخادم: $kBaseUrl',
            textAlign: TextAlign.center,
            textDirection: TextDirection.ltr,
            style: TextStyle(fontSize: 11, color: scheme.outline),
          ),
        ],
      ),
    );
  }
}
