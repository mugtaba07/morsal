<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FreeOrderOffer extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'free_order_id' => 'integer',
        'delivery_man_id' => 'integer',
        'price' => 'float',
        'eta_minutes' => 'integer',
    ];

    public function freeOrder()
    {
        return $this->belongsTo(FreeOrder::class, 'free_order_id');
    }

    public function deliveryMan()
    {
        return $this->belongsTo(DeliveryMan::class, 'delivery_man_id');
    }
}
