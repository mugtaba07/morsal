import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:morsal/controller/auth_controller.dart';
import 'package:morsal/controller/free_order_controller.dart';
import 'package:morsal/controller/location_controller.dart';
import 'package:morsal/controller/user_controller.dart';
import 'package:morsal/data/model/body/free_order_body.dart';
import 'package:morsal/data/model/response/address_model.dart';
import 'package:morsal/helper/price_converter.dart';
import 'package:morsal/helper/route_helper.dart';
import 'package:morsal/util/dimensions.dart';
import 'package:morsal/util/styles.dart';
import 'package:morsal/view/base/custom_app_bar.dart';
import 'package:morsal/view/base/custom_button.dart';
import 'package:morsal/view/base/custom_snackbar.dart';
import 'package:morsal/view/base/custom_text_field.dart';
import 'package:morsal/view/screens/location/pick_map_screen.dart';
import 'package:morsal/view/screens/parcel/widget/address_dialog.dart';
import 'package:morsal/view/screens/free_order/widget/voice_note_widget.dart';

class FreeOrderScreen extends StatefulWidget {
  const FreeOrderScreen({Key? key}) : super(key: key);

  @override
  State<FreeOrderScreen> createState() => _FreeOrderScreenState();
}

class _FreeOrderScreenState extends State<FreeOrderScreen> {
  final TextEditingController _descController = TextEditingController();
  final TextEditingController _placeController = TextEditingController();
  final TextEditingController _pickupLandmarkController = TextEditingController();
  final TextEditingController _dropLandmarkController = TextEditingController();
  final TextEditingController _itemPriceController = TextEditingController();
  final TextEditingController _feeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final controller = Get.find<FreeOrderController>();
    controller.resetForm();
    if (Get.find<AuthController>().isLoggedIn()) {
      // العنوان الافتراضي للعميل كموقع تسليم مبدئي
      controller.setDropAddress(Get.find<LocationController>().getUserAddress());
      if (Get.find<LocationController>().addressList == null) {
        Get.find<LocationController>().getAddressList();
      }
      if (Get.find<UserController>().userInfoModel == null) {
        Get.find<UserController>().getUserInfo();
      }
    }
  }

  @override
  void dispose() {
    _descController.dispose();
    _placeController.dispose();
    _pickupLandmarkController.dispose();
    _dropLandmarkController.dispose();
    _itemPriceController.dispose();
    _feeController.dispose();
    super.dispose();
  }

  String? _autoFee; // آخر قيمة وضعها التطبيق تلقائيًا في حقل الأجرة

  String _fmt(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);

  /// يحسب الأجرة المقترحة ويملأ الحقل إذا كان فارغًا أو لم يعدّله العميل بنفسه
  Future<void> _refreshEstimate() async {
    final c = Get.find<FreeOrderController>();
    await c.fetchEstimate();
    final est = c.estimate;
    if (!mounted || est == null || !est.available || est.suggestedFee == null) return;
    final current = _feeController.text.trim();
    if (current.isEmpty || current == _autoFee) {
      _autoFee = _fmt(est.suggestedFee!);
      setState(() => _feeController.text = _autoFee!);
    }
  }

  Widget _feeSuggestion(BuildContext context, FreeOrderController c) {
    final est = c.estimate;
    final Color primary = Theme.of(context).primaryColor;
    if (c.isEstimating) {
      return Row(children: [
        SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: primary)),
        const SizedBox(width: Dimensions.paddingSizeSmall),
        Text('free_order_calculating_fee'.tr, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall)),
      ]);
    }
    if (est != null && est.available) {
      return Container(
        padding: const EdgeInsets.all(Dimensions.paddingSizeSmall),
        decoration: BoxDecoration(color: primary.withOpacity(0.08), borderRadius: BorderRadius.circular(Dimensions.radiusSmall)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            '${'free_order_fee_suggestion'.tr}  •  ${est.distanceKm?.toStringAsFixed(1) ?? ''} ${'km'.tr}',
            style: robotoMedium.copyWith(fontSize: Dimensions.fontSizeSmall),
          ),
          const SizedBox(height: Dimensions.paddingSizeExtraSmall),
          Wrap(spacing: 8, children: est.options.map((v) => ChoiceChip(
            label: Text(PriceConverter.convertPrice(v)),
            selected: _feeController.text.trim() == _fmt(v),
            selectedColor: primary.withOpacity(0.25),
            onSelected: (_) => setState(() => _feeController.text = _fmt(v)),
          )).toList()),
          Text('free_order_higher_fee_hint'.tr, style: robotoRegular.copyWith(
            fontSize: Dimensions.fontSizeExtraSmall, color: Theme.of(context).disabledColor,
          )),
        ]),
      );
    }
    if (c.pickupAddress == null) {
      return Text('free_order_fee_hint_select_pickup'.tr, style: robotoRegular.copyWith(
        fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor,
      ));
    }
    return const SizedBox();
  }

  void _pickOnMap({required bool isPickup}) {
    Get.toNamed(RouteHelper.getPickMapRoute('free-order', false), arguments: PickMapScreen(
      fromSignUp: false, fromAddAddress: false, canRoute: false, route: '',
      onPicked: (AddressModel address) {
        if (isPickup) {
          Get.find<FreeOrderController>().setPickupAddress(address);
        } else {
          Get.find<FreeOrderController>().setDropAddress(address);
        }
        _refreshEstimate();
      },
    ));
  }

  Future<void> _submit() async {
    final controller = Get.find<FreeOrderController>();
    final drop = controller.dropAddress;
    final user = Get.find<UserController>().userInfoModel;

    if (!Get.find<AuthController>().isLoggedIn()) {
      showCustomSnackBar('you_are_not_logged_in'.tr);
    } else if (_descController.text.trim().isEmpty && controller.voicePath == null) {
      showCustomSnackBar('free_order_enter_description_or_voice'.tr);
    } else if (drop == null || drop.latitude == null || drop.longitude == null) {
      showCustomSnackBar('select_destination_address'.tr);
    } else {
      final body = FreeOrderBody(
        description: _descController.text.trim(),
        pickupPlaceName: _placeController.text.trim(),
        pickupAddress: controller.pickupAddress?.address,
        pickupLatitude: controller.pickupAddress?.latitude,
        pickupLongitude: controller.pickupAddress?.longitude,
        dropAddress: drop.address ?? '',
        pickupLandmark: _pickupLandmarkController.text.trim(),
        dropLandmark: _dropLandmarkController.text.trim(),
        dropLatitude: drop.latitude!,
        dropLongitude: drop.longitude!,
        contactPersonName: drop.contactPersonName ?? '${user?.fName ?? ''} ${user?.lName ?? ''}'.trim(),
        contactPersonNumber: drop.contactPersonNumber ?? user?.phone ?? '',
        estimatedItemPrice: double.tryParse(_itemPriceController.text.trim()),
        suggestedDeliveryFee: double.tryParse(_feeController.text.trim()),
      );
      final int? id = await controller.submit(body);
      if (id != null) Get.offNamed(RouteHelper.getFreeOrderOffersRoute(id));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'free_order'.tr),
      body: SafeArea(
        child: GetBuilder<FreeOrderController>(builder: (controller) {
          return Column(children: [
            Expanded(child: SingleChildScrollView(
              padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
              child: Center(child: SizedBox(width: Dimensions.webMaxWidth, child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [

                Align(
                  alignment: AlignmentDirectional.centerEnd,
                  child: TextButton.icon(
                    onPressed: () => Get.toNamed(RouteHelper.getFreeOrderListRoute()),
                    icon: const Icon(Icons.history, size: 18),
                    label: Text('my_free_orders'.tr),
                  ),
                ),
                Text('free_order_what_do_you_need'.tr, style: robotoMedium),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                CustomTextField(
                  titleText: 'free_order_description_hint'.tr,
                  hintText: 'free_order_description_hint'.tr,
                  controller: _descController, maxLines: 4, showTitle: false,
                  inputType: TextInputType.multiline, inputAction: TextInputAction.newline,
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                VoiceRecorderField(path: controller.voicePath, onChanged: controller.setVoicePath),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                // صورة اختيارية للمنتج
                Row(children: [
                  OutlinedButton.icon(
                    onPressed: controller.pickImage,
                    icon: const Icon(Icons.add_a_photo_outlined),
                    label: Text('free_order_add_photo'.tr),
                  ),
                  const SizedBox(width: Dimensions.paddingSizeSmall),
                  if (controller.pickedImage != null) Stack(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
                      child: kIsWeb
                        ? Image.network(controller.pickedImage!.path, width: 60, height: 60, fit: BoxFit.cover)
                        : Image.file(File(controller.pickedImage!.path), width: 60, height: 60, fit: BoxFit.cover),
                    ),
                    Positioned(top: 0, right: 0, child: InkWell(
                      onTap: controller.removeImage,
                      child: const CircleAvatar(radius: 10, backgroundColor: Colors.red, child: Icon(Icons.close, size: 12, color: Colors.white)),
                    )),
                  ]),
                ]),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                Text('free_order_pickup_from'.tr, style: robotoMedium),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                CustomTextField(
                  titleText: 'free_order_place_name'.tr, hintText: 'free_order_place_name'.tr,
                  controller: _placeController, showTitle: false, inputAction: TextInputAction.next,
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                _locationTile(
                  context, icon: Icons.store_mall_directory_outlined,
                  text: controller.pickupAddress?.address ?? 'free_order_pickup_optional'.tr,
                  onTap: () => _pickOnMap(isPickup: true),
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                CustomTextField(
                  titleText: 'free_order_landmark'.tr, hintText: 'free_order_landmark_hint'.tr,
                  controller: _pickupLandmarkController, showTitle: false, inputAction: TextInputAction.next,
                ),
                const SizedBox(height: Dimensions.paddingSizeLarge),

                Text('free_order_deliver_to'.tr, style: robotoMedium),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                _locationTile(
                  context, icon: Icons.location_on_outlined,
                  text: controller.dropAddress?.address ?? 'select_destination_address'.tr,
                  onTap: () => _pickOnMap(isPickup: false),
                ),
                const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                TextButton(
                  onPressed: () {
                    if (Get.find<AuthController>().isLoggedIn()) {
                      Get.dialog(AddressDialog(onTap: (AddressModel a) {
                        controller.setDropAddress(a);
                        _refreshEstimate();
                      }));
                    } else {
                      showCustomSnackBar('you_are_not_logged_in'.tr);
                    }
                  },
                  child: Text('set_from_saved_address'.tr),
                ),
                const SizedBox(height: Dimensions.paddingSizeExtraSmall),
                CustomTextField(
                  titleText: 'free_order_landmark'.tr, hintText: 'free_order_landmark_hint'.tr,
                  controller: _dropLandmarkController, showTitle: false, inputAction: TextInputAction.next,
                ),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                _landmarkChips(_dropLandmarkController),
                const SizedBox(height: Dimensions.paddingSizeDefault),

                _feeSuggestion(context, controller),
                const SizedBox(height: Dimensions.paddingSizeSmall),

                Row(children: [
                  Expanded(child: CustomTextField(
                    titleText: 'free_order_item_price'.tr, hintText: 'free_order_item_price'.tr,
                    controller: _itemPriceController, inputType: TextInputType.number, showTitle: true,
                    inputAction: TextInputAction.next,
                  )),
                  const SizedBox(width: Dimensions.paddingSizeSmall),
                  Expanded(child: CustomTextField(
                    titleText: 'free_order_suggested_fee'.tr, hintText: 'free_order_suggested_fee'.tr,
                    controller: _feeController, inputType: TextInputType.number, showTitle: true,
                    inputAction: TextInputAction.done,
                  )),
                ]),
                const SizedBox(height: Dimensions.paddingSizeSmall),
                Text('free_order_offers_note'.tr, style: robotoRegular.copyWith(
                  fontSize: Dimensions.fontSizeSmall, color: Theme.of(context).disabledColor,
                )),
              ]))),
            )),

            CustomButton(
              margin: const EdgeInsets.all(Dimensions.paddingSizeSmall),
              buttonText: 'free_order_send'.tr,
              isLoading: controller.isLoading,
              onPressed: controller.isLoading ? null : _submit,
            ),
          ]);
        }),
      ),
    );
  }

  // أزرار سريعة: الضغط يكتب «بجوار ...» في الحقل ويترك المؤشر في آخره ليكمل العميل الاسم
  Widget _landmarkChips(TextEditingController controller) {
    const keys = ['landmark_mosque', 'landmark_pharmacy', 'landmark_fuel', 'landmark_school', 'landmark_hospital', 'landmark_market'];
    return Wrap(spacing: 8, runSpacing: 0, children: keys.map((k) => ActionChip(
      label: Text(k.tr, style: robotoRegular.copyWith(fontSize: Dimensions.fontSizeSmall)),
      onPressed: () {
        final text = '${'landmark_next_to'.tr} ${k.tr} ';
        controller.value = TextEditingValue(text: text, selection: TextSelection.collapsed(offset: text.length));
      },
    )).toList());
  }

  Widget _locationTile(BuildContext context, {required IconData icon, required String text, required VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(Dimensions.paddingSizeDefault),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Dimensions.radiusSmall),
          border: Border.all(color: Theme.of(context).primaryColor.withOpacity(0.5)),
        ),
        child: Row(children: [
          Icon(icon, color: Theme.of(context).primaryColor),
          const SizedBox(width: Dimensions.paddingSizeSmall),
          Expanded(child: Text(text, maxLines: 2, overflow: TextOverflow.ellipsis, style: robotoRegular)),
          const Icon(Icons.chevron_right),
        ]),
      ),
    );
  }
}
