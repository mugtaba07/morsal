double? _toDouble(dynamic v) => v == null ? null : double.tryParse(v.toString());
int? _toInt(dynamic v) => v == null ? null : int.tryParse(v.toString());

class FreeOrderModel {
  int? id;
  String? description;
  String? image;
  String? voiceUrl;
  String? pickupPlaceName;
  String? pickupAddress;
  String? dropAddress;
  String? pickupLandmark;
  String? dropLandmark;
  double? estimatedItemPrice;
  double? suggestedDeliveryFee;
  String? status; // open | accepted | cancelled | expired
  int? orderId;
  int? acceptedOfferId;
  DateTime? expiresAt;
  DateTime? createdAt;
  int? pendingOffersCount;

  FreeOrderModel.fromJson(Map<String, dynamic> json) {
    id = _toInt(json['id']);
    description = json['description'];
    image = json['image'];
    voiceUrl = json['voice_url'];
    pickupPlaceName = json['pickup_place_name'];
    pickupAddress = json['pickup_address'];
    dropAddress = json['drop_address'];
    pickupLandmark = json['pickup_landmark'];
    dropLandmark = json['drop_landmark'];
    estimatedItemPrice = _toDouble(json['estimated_item_price']);
    suggestedDeliveryFee = _toDouble(json['suggested_delivery_fee']);
    status = json['status'];
    orderId = _toInt(json['order_id']);
    acceptedOfferId = _toInt(json['accepted_offer_id']);
    createdAt = json['created_at'] != null ? DateTime.tryParse(json['created_at'].toString())?.toLocal() : null;
    pendingOffersCount = _toInt(json['pending_offers_count']);
    expiresAt = json['expires_at'] != null ? DateTime.tryParse(json['expires_at'].toString())?.toLocal() : null;
  }

  bool get isOpen => status == 'open';
  bool get isAccepted => status == 'accepted';

  /// الوقت المتبقي لاستقبال العروض (null إذا لم يُحدد)
  Duration? get remaining => expiresAt?.difference(DateTime.now());
}

class FreeOrderOfferModel {
  int? id;
  double? price;
  int? etaMinutes;
  String? note;
  String? status;
  int? deliveryManId;
  String? deliveryManName;
  String? deliveryManImage;
  String? deliveryManPhone;
  double? rating;
  int? ordersCount;

  FreeOrderOfferModel.fromJson(Map<String, dynamic> json) {
    id = _toInt(json['id']);
    price = _toDouble(json['price']);
    etaMinutes = _toInt(json['eta_minutes']);
    note = json['note'];
    status = json['status'];
    final dm = json['delivery_man'];
    if (dm is Map<String, dynamic>) {
      deliveryManId = _toInt(dm['id']);
      deliveryManName = dm['name'];
      deliveryManImage = dm['image'];
      deliveryManPhone = dm['phone'];
      rating = _toDouble(dm['rating']);
      ordersCount = _toInt(dm['orders_count']);
    }
  }
}

/// تقدير الأجرة من المسافة (نفس معادلة الطرود في لوحة الإدارة)
class FeeEstimateModel {
  bool available = false;
  double? distanceKm;
  double? suggestedFee;
  List<double> options = [];

  FeeEstimateModel.fromJson(Map<String, dynamic> json) {
    available = json['available'] == true;
    distanceKm = _toDouble(json['distance_km']);
    suggestedFee = _toDouble(json['suggested_fee']);
    for (final o in (json['options'] as List? ?? [])) {
      final v = _toDouble(o);
      if (v != null) options.add(v);
    }
  }
}
