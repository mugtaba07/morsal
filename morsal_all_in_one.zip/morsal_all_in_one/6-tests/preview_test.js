const { JSDOM, VirtualConsole } = require('jsdom');
const fs = require('fs');
const errors = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errors.push('jsdomError: ' + e.message));
vc.on('error', e => errors.push('console.error: ' + e));
const html = fs.readFileSync(require('path').join(__dirname, '..', '4-previews', 'courier_app_preview.html'), 'utf8');
const dom = new JSDOM(html, { runScripts: 'dangerously', virtualConsole: vc, pretendToBeVisual: true });
const w = dom.window, d = w.document;
let fails = 0;
function check(name, cond, extra) { if (!cond) fails++; console.log((cond ? 'PASS ' : 'FAIL ') + name + (cond ? '' : '  ' + (extra || ''))); }
const $ = s => d.querySelector(s), $$ = s => [...d.querySelectorAll(s)];
const click = el => { if (!el) throw new Error('عنصر غير موجود'); el.dispatchEvent(new w.MouseEvent('click', { bubbles: true })); };
const text = () => d.getElementById('app').textContent;
const toast = () => d.getElementById('toast').textContent;

check('شاشة الدخول تظهر أولًا', text().includes('سجّل دخولك لاستقبال الطلبات'));
click($('[data-act=login]'));
check('بعد الدخول: عنوان الطلبات القريبة', $('.appbar h1').textContent === 'الطلبات القريبة');
check('3 طلبات في القائمة', $$('.card[data-act=open]').length === 3, $$('.card[data-act=open]').length);
check('الترتيب بالأقرب أولًا (102 قبل 101 قبل 103)? الأقرب هو 101=1.8', $$('.card[data-act=open]')[0].dataset.id === '101');
check('الطلب الصوتي يعرض «رسالة صوتية»', text().includes('رسالة صوتية'));
check('طلب 103 عليه عرضك: 1,200 ج.س', text().includes('عرضك: 1,200 ج.س'));
check('شريط التنقل 4 تبويبات', $$('.nav button').length === 4);

// تفاصيل وتقديم عرض
click($('.card[data-act=open][data-id="101"]'));
check('شاشة التفاصيل', $('.appbar h1').textContent === 'طلب #101');
check('السعر مُعبّأ بأجرة العميل 1500', $('#price').value === '1500', $('#price').value);
check('أقرب معلم يظهر', text().includes('أقرب معلم: بجوار مسجد النور'));
click($('[data-act=eta][data-m="30"]'));
check('اختيار وقت الوصول 30', $('[data-act=eta][data-m="30"]').classList.contains('on'));
$('#price').value = '١٦٠٠'; // أرقام عربية
click($('[data-act=send]'));
check('الرجوع للقائمة بعد الإرسال', $('.appbar h1').textContent === 'الطلبات القريبة');
check('البطاقة تعرض عرضك 1,600 ج.س (من أرقام عربية)', text().includes('عرضك: 1,600 ج.س'), text().slice(0, 200));
check('رسالة النجاح', toast().includes('تم إرسال عرضك'));

// تحقق من السعر الفارغ
click($('.card[data-act=open][data-id="102"]'));
$('#price').value = '';
click($('[data-act=send]'));
check('رفض السعر الفارغ', toast().includes('أدخل سعر التوصيل'));
click($('[data-act=back]'));

// غير متاح لا يقدّم عروضًا
click($('[data-act=toggle]'));
check('تحذير غير متاح في القائمة', text().includes('أنت غير متاح حاليًا'));
click($('.card[data-act=open][data-id="102"]'));
$('#price').value = '2000';
click($('[data-act=send]'));
check('منع التقديم وأنت غير متاح', toast().includes('فعّل زر «متاح» أولًا'));
click($('[data-act=back]'));
click($('[data-act=toggle]'));

// تعديل وسحب عرض موجود
click($('.card[data-act=open][data-id="101"]'));
check('يظهر «عرضك الحالي» ويعرض زر تحديث', text().includes('عرضك الحالي: 1,600 ج.س') && text().includes('تحديث العرض'));
click($('[data-act=withdraw]'));
check('سحب العرض يزيل الشارة', !text().includes('عرضك: 1,600 ج.س') && toast().includes('تم سحب عرضك'));

// عروضي ومحاكاة قبول العميل
click($$('.nav button')[2]);
check('تبويب عروضي', $('.appbar h1').textContent === 'عروضي');
check('عرض مرفوض وعرض مسحوب موجودان', text().includes('لم يُقبل') && text().includes('مسحوب'));
const sim = $('[data-act=sim-accept]');
check('زر محاكاة قبول العميل موجود لعرض 103', !!sim);
click(sim);
check('حالة العرض: تم قبول عرضك', text().includes('تم قبول عرضك'));

// طلباتي: استلام ثم تسليم
click($$('.nav button')[1]);
check('طلب حالي ظاهر في طلباتي', text().includes('طلب #100231') && text().includes('في الطريق للمحل'));
check('نص أجرتك 1,200 ج.س', text().includes('أجرتك: 1,200 ج.س'));
click($('[data-act=picked]'));
check('نافذة تأكيد الاستلام', !!$('.dialog') && text().includes('هل استلمت الطلب من المحل؟'));
click($('[data-act=modal-yes]'));
check('الحالة صارت في الطريق للعميل', text().includes('في الطريق للعميل') && text().includes('تم التسليم'));
click($('[data-act=delivered]'));
check('نافذة رمز التأكيد', !!$('#otp'));
$('#otp').value = '9999';
click($('[data-act=otp-ok]'));
check('رمز خاطئ يُرفض', toast().includes('رمز التأكيد غير صحيح') && !!$('#otp'));
$('#otp').value = '1234';
click($('[data-act=otp-ok]'));
check('رمز صحيح: يتم التسليم ويفرغ الطلب', toast().includes('تم تسليم الطلب') && text().includes('لا توجد طلبات حالية'));

// الحساب والخروج
click($$('.nav button')[3]);
check('شاشة الحساب', text().includes('خالد العتيبي') && text().includes('كاش بحوزتك'));
click($('[data-act=logout]'));
check('الخروج يعيد شاشة الدخول', text().includes('تسجيل الدخول'));

check('لا أخطاء JavaScript', errors.length === 0, errors.join(' | '));
console.log(fails === 0 ? '\nALL PASSED' : '\n' + fails + ' FAILURES');
process.exit(0);
