<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FreeOrder extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'user_id' => 'integer',
        'zone_id' => 'integer',
        'module_id' => 'integer',
        'estimated_item_price' => 'float',
        'suggested_delivery_fee' => 'float',
        'accepted_offer_id' => 'integer',
        'order_id' => 'integer',
        'expires_at' => 'datetime',
    ];

    public function customer()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function offers()
    {
        return $this->hasMany(FreeOrderOffer::class, 'free_order_id');
    }

    public function order()
    {
        return $this->belongsTo(Order::class, 'order_id');
    }

    // طلب مفتوح ولم تنتهِ مهلته
    public function scopeOpen($query)
    {
        return $query->where('status', 'open')
            ->where(function ($q) {
                $q->whereNull('expires_at')->orWhere('expires_at', '>', now());
            });
    }

    // تحويل الطلبات المنتهية إلى expired (استدعاء خفيف قبل القوائم)
    public static function expireStale()
    {
        return static::where('status', 'open')
            ->whereNotNull('expires_at')
            ->where('expires_at', '<=', now())
            ->update(['status' => 'expired']);
    }
}
