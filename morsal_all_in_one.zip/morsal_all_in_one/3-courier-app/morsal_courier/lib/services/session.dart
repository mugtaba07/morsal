import 'package:shared_preferences/shared_preferences.dart';

import '../api/api_client.dart';
import '../config.dart';

/// حفظ الجلسة وإعدادات العملة محليًا
class Session {
  static const String _tokenKey = 'dm_token';
  static const String _symbolKey = 'currency_symbol';
  static const String _afterKey = 'currency_after';
  static const String _otpKey = 'otp_required';

  static String currencySymbol = kDefaultCurrency;
  static bool currencyAfter = true; // الرمز بعد الرقم
  static bool otpRequired = true; // رمز تأكيد التسليم من العميل

  static bool get isLoggedIn => (ApiClient.instance.token ?? '').isNotEmpty;

  static Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    ApiClient.instance.token = p.getString(_tokenKey);
    currencySymbol = p.getString(_symbolKey) ?? kDefaultCurrency;
    currencyAfter = p.getBool(_afterKey) ?? true;
    otpRequired = p.getBool(_otpKey) ?? true;
  }

  static Future<void> saveToken(String token) async {
    ApiClient.instance.token = token;
    final p = await SharedPreferences.getInstance();
    await p.setString(_tokenKey, token);
  }

  static Future<void> saveConfig({
    required String symbol,
    required bool after,
    required bool otp,
  }) async {
    currencySymbol = symbol;
    currencyAfter = after;
    otpRequired = otp;
    final p = await SharedPreferences.getInstance();
    await p.setString(_symbolKey, symbol);
    await p.setBool(_afterKey, after);
    await p.setBool(_otpKey, otp);
  }

  static Future<void> clear() async {
    ApiClient.instance.token = null;
    final p = await SharedPreferences.getInstance();
    await p.remove(_tokenKey);
  }
}
