import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> _open(BuildContext context, Uri uri, String failMessage) async {
  bool ok = false;
  try {
    ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {
    ok = false;
  }
  if (!ok && context.mounted) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(failMessage)));
  }
}

/// فتح الاتجاهات إلى الموقع في تطبيق الخرائط
Future<void> openMap(BuildContext context, double lat, double lng) {
  return _open(
    context,
    Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng'),
    'تعذر فتح الخرائط',
  );
}

Future<void> callPhone(BuildContext context, String phone) {
  return _open(context, Uri(scheme: 'tel', path: phone), 'تعذر فتح تطبيق الاتصال');
}
