import 'dart:convert';
import 'models.dart';

// نسخ طبق الأصل من دوال widgets/common.dart (لا تعتمد على Flutter)
String formatNumber(num v) {
  final whole = v == v.roundToDouble();
  final fixed = whole ? v.round().toString() : v.toStringAsFixed(2);
  final parts = fixed.split('.');
  final intPart = parts[0];
  final buf = StringBuffer();
  for (int i = 0; i < intPart.length; i++) {
    final fromEnd = intPart.length - i;
    buf.write(intPart[i]);
    if (fromEnd > 1 && fromEnd % 3 == 1 && intPart[i] != '-') {
      buf.write(',');
    }
  }
  if (parts.length > 1) buf.write('.${parts[1]}');
  return buf.toString();
}

double? parseNumber(String input) {
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  final buf = StringBuffer();
  for (final ch in input.trim().split('')) {
    final i = arabicDigits.indexOf(ch);
    if (i >= 0) {
      buf.write(i);
    } else if (ch == '٫') {
      buf.write('.');
    } else if (ch == ',' || ch == '،' || ch == ' ') {
      continue;
    } else {
      buf.write(ch);
    }
  }
  return double.tryParse(buf.toString());
}

int failures = 0;
void check(String name, Object? actual, Object? expected) {
  final ok = actual == expected;
  if (!ok) failures++;
  print('${ok ? "PASS" : "FAIL"}  $name  -> $actual ${ok ? "" : "(expected $expected)"}');
}

void main() {
  // --- أرقام
  check('fmt 1500', formatNumber(1500), '1,500');
  check('fmt 1234567', formatNumber(1234567), '1,234,567');
  check('fmt 500', formatNumber(500), '500');
  check('fmt 12.5', formatNumber(12.5), '12.50');
  check('fmt -1500', formatNumber(-1500), '-1,500');
  check('fmt -500', formatNumber(-500), '-500');
  check('fmt 0', formatNumber(0), '0');
  check('parse arabic', parseNumber('١٥٠٠'), 1500.0);
  check('parse thousands comma', parseNumber('1,500'), 1500.0);
  check('parse arabic decimal', parseNumber('١٢٫٥'), 12.5);
  check('parse junk', parseNumber('abc'), null);

  // --- طلب قريب (شكل استجابة nearby في الباك إند)
  final nearby = jsonDecode('''
  [{"id": 7, "description": "قهوة وكرواسون", "image": null, "voice": "v.m4a",
    "voice_url": "https://x.com/storage/app/public/free_order_voice/v.m4a",
    "pickup_place_name": "كافيه ريزا", "pickup_address": null, "pickup_landmark": "بجوار مسجد النور",
    "pickup_latitude": "15.5007", "pickup_longitude": "32.5599",
    "drop_address": "الخرطوم", "drop_landmark": null, "drop_latitude": "15.51", "drop_longitude": "32.57",
    "estimated_item_price": 4500.0, "suggested_delivery_fee": "1500.000", "status": "open",
    "expires_at": "2030-01-01T10:00:00.000000Z", "distance_to_pickup_km": 2.35, "trip_distance_km": null,
    "my_offer": {"id": 3, "price": 1400.0, "eta_minutes": 15, "status": "pending"}, "customer_name": "أحمد"}]
  ''') as List;
  final r = FreeRequest.fromJson(asMap(nearby.first)!);
  check('req id', r.id, 7);
  check('req hasVoice', r.hasVoice, true);
  check('req pickup lat parsed from string', r.pickupLat, 15.5007);
  check('req fee parsed from "1500.000"', r.suggestedFee, 1500.0);
  check('req null trip distance', r.tripDistanceKm, null);
  check('req myOffer price', r.myOffer?.price, 1400.0);
  check('req myOffer pending', r.myOffer?.isPending, true);
  check('req has remaining', r.remaining != null, true);
  check('req landmark', r.pickupLandmark, 'بجوار مسجد النور');

  // --- طلب حالي (شكل current-orders): receiver_details مرة Map ومرة نص JSON
  final noteWithVoice = 'قهوة لاتيه\\nرسالة صوتية: https://x.com/storage/app/public/free_order_voice/abc.m4a';
  final orderMap = jsonDecode('''
  {"id": 100005, "order_status": "accepted", "order_note": "$noteWithVoice", "delivery_charge": 1500.0,
   "payment_method": "cash_on_delivery",
   "delivery_address": {"contact_person_name": "أحمد علي", "contact_person_number": "+249911111111", "address": "كافيه ريزا", "latitude": "15.5", "longitude": "32.5"},
   "receiver_details": {"contact_person_name": "أحمد علي", "contact_person_number": "+249911111111", "address": "الخرطوم (أقرب معلم: بجوار مسجد)", "latitude": "15.6", "longitude": "32.6"},
   "customer": {"f_name": "أحمد", "l_name": "علي", "phone": "+249911111111"}}
  ''');
  final o = CourierOrder.fromJson(asMap(orderMap)!);
  check('order id', o.id, 100005);
  check('order voiceUrl', o.voiceUrl, 'https://x.com/storage/app/public/free_order_voice/abc.m4a');
  check('order noteText strips voice line', o.noteText, 'قهوة لاتيه');
  check('order drop address', o.drop.address, 'الخرطوم (أقرب معلم: بجوار مسجد)');
  check('order drop hasLocation', o.drop.hasLocation, true);
  check('order customerName', o.customerName, 'أحمد علي');
  check('order contactPhone', o.contactPhone, '+249911111111');
  check('order not picked up', o.isPickedUp, false);

  final orderStr = jsonDecode(jsonEncode({
    'id': 9, 'order_status': 'picked_up', 'order_note': '', 'delivery_charge': 800,
    'delivery_address': jsonEncode({'address': 'A', 'latitude': '1', 'longitude': '2'}),
    'receiver_details': jsonEncode({'address': 'B', 'latitude': '3', 'longitude': '4'}),
  }));
  final o2 = CourierOrder.fromJson(asMap(orderStr)!);
  check('JSON-string receiver_details parsed', o2.drop.address, 'B');
  check('JSON-string pickup parsed', o2.pickup.lat, 1.0);
  check('order2 isPickedUp', o2.isPickedUp, true);
  check('order2 no customer -> empty phone', o2.contactPhone, '');

  // --- عروضي
  final offer = OfferItem.fromJson(asMap(jsonDecode(
      '{"id":4,"free_order_id":7,"price":"1400.000","eta_minutes":15,"note":null,"status":"accepted","free_order":{"id":7,"description":"قهوة","status":"accepted","order_id":100005}}'))!);
  check('offer price', offer.price, 1400.0);
  check('offer orderId', offer.orderId, 100005);
  check('offer note null', offer.note, null);

  // --- الملف الشخصي (active قد يصل 0/1 أو bool)
  final p1 = CourierProfile.fromJson({'f_name': 'خالد', 'l_name': 'العتيبي', 'active': 1, 'avg_rating': '4.8', 'todays_earning': '2500.5'});
  check('profile name', p1.name, 'خالد العتيبي');
  check('profile active from 1', p1.active, true);
  check('profile rating from string', p1.rating, 4.8);
  check('profile earnings', p1.todaysEarning, 2500.5);
  check('profile active false from 0', CourierProfile.fromJson({'active': 0}).active, false);
  check('empty map -> no crash', CourierProfile.fromJson(<String, dynamic>{}).name, '');
  check('FreeRequest from empty map', FreeRequest.fromJson(<String, dynamic>{}).id, 0);

  print('\n${failures == 0 ? "ALL PASSED" : "$failures FAILURES"}');
}
