import '../config.dart';
import '../models/models.dart';
import '../services/session.dart';
import 'api_client.dart';
import 'demo_backend.dart';

/// كل استدعاءات الباك إند الخاصة بالمندوب في مكان واحد
class CourierApi {
  static final ApiClient _c = ApiClient.instance;

  /// تسجيل الدخول: الهاتف بصيغة دولية (مثل +249912345678)
  static Future<String> login(String phone, String password) async {
    if (kDemoMode) return 'demo-token'; // أي بيانات مقبولة في التجربة
    final res = await _c.post(
      '/auth/delivery-man/login',
      body: {'phone': phone, 'password': password},
      auth: false,
    );
    final token = res is Map ? res['token']?.toString() : null;
    if (token == null || token.isEmpty) {
      throw const ApiException('تعذر تسجيل الدخول، تحقق من البيانات');
    }
    return token;
  }

  /// قراءة العملة وإعداد رمز التسليم من الإعدادات العامة (اختياري)
  static Future<void> refreshConfig() async {
    if (kDemoMode) return;
    final res = await _c.get('/config', auth: false);
    if (res is! Map) return;
    final symbol = res['currency_symbol']?.toString();
    final dir = res['currency_symbol_direction']?.toString();
    await Session.saveConfig(
      symbol: (symbol == null || symbol.isEmpty) ? Session.currencySymbol : symbol,
      after: dir == null ? Session.currencyAfter : dir != 'left',
      otp: asBool(res['order_delivery_verification']),
    );
  }

  static Future<CourierProfile> profile() async {
    if (kDemoMode) return DemoBackend.instance.profile();
    final res = await _c.get('/delivery-man/profile');
    return CourierProfile.fromJson(asMap(res) ?? <String, dynamic>{});
  }

  /// يقلب حالة المندوب بين متاح وغير متاح
  static Future<void> toggleActive() async {
    if (kDemoMode) return DemoBackend.instance.toggleActive();
    await _c.post('/delivery-man/update-active-status');
  }

  static Future<List<FreeRequest>> nearby({double? lat, double? lng}) async {
    if (kDemoMode) return DemoBackend.instance.nearby();
    final query = <String, String>{};
    if (lat != null && lng != null) {
      query['latitude'] = lat.toString();
      query['longitude'] = lng.toString();
    }
    final res = await _c.get('/delivery-man/free-order/nearby', query: query);
    return asList(res).map((e) => FreeRequest.fromJson(asMap(e) ?? <String, dynamic>{})).toList();
  }

  static Future<void> submitOffer({
    required int freeOrderId,
    required double price,
    int? etaMinutes,
    String? note,
  }) async {
    if (kDemoMode) {
      return DemoBackend.instance.submitOffer(
        freeOrderId: freeOrderId,
        price: price,
        etaMinutes: etaMinutes,
        note: note,
      );
    }
    await _c.post('/delivery-man/free-order/offer', body: {
      'free_order_id': freeOrderId,
      'price': price,
      if (etaMinutes != null) 'eta_minutes': etaMinutes,
      if (note != null && note.isNotEmpty) 'note': note,
    });
  }

  static Future<void> withdrawOffer(int offerId) async {
    if (kDemoMode) return DemoBackend.instance.withdrawOffer(offerId);
    await _c.put('/delivery-man/free-order/withdraw-offer', body: {'offer_id': offerId});
  }

  static Future<List<OfferItem>> myOffers() async {
    if (kDemoMode) return DemoBackend.instance.myOffers();
    final res = await _c.get('/delivery-man/free-order/my-offers');
    return asList(res).map((e) => OfferItem.fromJson(asMap(e) ?? <String, dynamic>{})).toList();
  }

  static Future<List<CourierOrder>> currentOrders() async {
    if (kDemoMode) return DemoBackend.instance.currentOrders();
    final res = await _c.get('/delivery-man/current-orders');
    return asList(res).map((e) => CourierOrder.fromJson(asMap(e) ?? <String, dynamic>{})).toList();
  }

  /// status: picked_up أو delivered (مع otp إذا كان التحقق مفعّلًا)
  static Future<void> updateOrderStatus(int orderId, String status, {String? otp}) async {
    if (kDemoMode) return DemoBackend.instance.updateOrderStatus(orderId, status, otp: otp);
    await _c.put('/delivery-man/update-order-status', body: {
      'order_id': orderId,
      'status': status,
      if (otp != null && otp.isNotEmpty) 'otp': otp,
    });
  }

  static Future<void> recordLocation(double lat, double lng) async {
    if (kDemoMode) return;
    await _c.post('/delivery-man/record-location-data', body: {
      'latitude': lat,
      'longitude': lng,
      'location': '$lat,$lng',
    });
  }
}
