<?php

namespace App\CentralLogics;

use App\Models\FreeOrder;
use App\Models\FreeOrderOffer;

class FreeOrderLogic
{
    // المدة الافتراضية لبقاء الطلب مفتوحًا لاستقبال العروض (بالدقائق)
    const EXPIRY_MINUTES = 30;
    // أقصى عدد للطلبات المفتوحة للعميل الواحد
    const MAX_OPEN_REQUESTS = 3;

    public static function distance_km($lat1, $lng1, $lat2, $lng2)
    {
        if ($lat1 === null || $lng1 === null || $lat2 === null || $lng2 === null) {
            return null;
        }
        $earth = 6371;
        $dLat = deg2rad((float)$lat2 - (float)$lat1);
        $dLng = deg2rad((float)$lng2 - (float)$lng1);
        $a = sin($dLat / 2) ** 2
            + cos(deg2rad((float)$lat1)) * cos(deg2rad((float)$lat2)) * sin($dLng / 2) ** 2;
        return round($earth * 2 * atan2(sqrt($a), sqrt(1 - $a)), 2);
    }

    // إرسال إشعار دون أن يفشل الطلب إذا تعذّر الإرسال
    public static function push($fcm_token, $title, $description, $free_order_id, $type)
    {
        if (!$fcm_token) {
            return;
        }
        try {
            Helpers::send_push_notif_to_device($fcm_token, [
                'title' => $title,
                'description' => $description,
                'order_id' => $free_order_id,
                'image' => '',
                'type' => $type,
            ]);
        } catch (\Exception $e) {
            // تجاهل أخطاء الإشعارات
        }
    }

    public static function format_request(FreeOrder $fo, $dm_lat = null, $dm_lng = null)
    {
        $data = [
            'id' => $fo->id,
            'description' => $fo->description,
            'image' => $fo->image,
            'voice' => $fo->voice,
            'voice_url' => $fo->voice ? asset('storage/app/public/free_order_voice/' . $fo->voice) : null,
            'pickup_place_name' => $fo->pickup_place_name,
            'pickup_address' => $fo->pickup_address,
            'pickup_landmark' => $fo->pickup_landmark,
            'pickup_latitude' => $fo->pickup_latitude,
            'pickup_longitude' => $fo->pickup_longitude,
            'drop_address' => $fo->drop_address,
            'drop_landmark' => $fo->drop_landmark,
            'drop_latitude' => $fo->drop_latitude,
            'drop_longitude' => $fo->drop_longitude,
            'estimated_item_price' => $fo->estimated_item_price,
            'suggested_delivery_fee' => $fo->suggested_delivery_fee,
            'payment_method' => $fo->payment_method,
            'status' => $fo->status,
            'order_id' => $fo->order_id,
            'accepted_offer_id' => $fo->accepted_offer_id,
            'expires_at' => $fo->expires_at,
            'created_at' => $fo->created_at,
        ];
        // المسافة بين المندوب ونقطة الشراء (أو التسليم إن لم تُحدد)
        $ref_lat = $fo->pickup_latitude ?: $fo->drop_latitude;
        $ref_lng = $fo->pickup_longitude ?: $fo->drop_longitude;
        $data['distance_to_pickup_km'] = self::distance_km($dm_lat, $dm_lng, $ref_lat, $ref_lng);
        $data['trip_distance_km'] = $fo->pickup_latitude
            ? self::distance_km($fo->pickup_latitude, $fo->pickup_longitude, $fo->drop_latitude, $fo->drop_longitude)
            : null;
        return $data;
    }

    public static function format_offer(FreeOrderOffer $offer, $with_phone = false)
    {
        $dm = $offer->deliveryMan;
        return [
            'id' => $offer->id,
            'free_order_id' => $offer->free_order_id,
            'price' => $offer->price,
            'eta_minutes' => $offer->eta_minutes,
            'note' => $offer->note,
            'status' => $offer->status,
            'created_at' => $offer->created_at,
            'delivery_man' => $dm ? [
                'id' => $dm->id,
                'name' => trim($dm->f_name . ' ' . $dm->l_name),
                'image' => $dm->image,
                'phone' => $with_phone ? $dm->phone : null,
                'rating' => $dm->relationLoaded('rating') && $dm->rating->count()
                    ? round((float)$dm->rating[0]->average, 1) : null,
                'orders_count' => (int)($dm->assigned_order_count ?? 0),
            ] : null,
        ];
    }
}
