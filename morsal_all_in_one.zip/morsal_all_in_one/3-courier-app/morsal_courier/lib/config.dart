/// عنوان السيرفر (نطاق لوحة الإدارة) بدون / في النهاية.
/// يمكن تمريره عند البناء: --dart-define=BASE_URL=https://admin.example.com
const String kBaseUrl = String.fromEnvironment(
  'BASE_URL',
  defaultValue: 'https://admin.example.com',
);

const String kApiPrefix = '/api/v1';

/// تحديث قائمة الطلبات القريبة وطلباتي كل كذا ثانية أثناء فتح الشاشة
const Duration kPollInterval = Duration(seconds: 10);

/// إرسال موقع المندوب للسيرفر أثناء فتح التطبيق وهو متاح
const Duration kLocationInterval = Duration(seconds: 20);

/// رمز العملة الافتراضي قبل قراءة الإعدادات من السيرفر
const String kDefaultCurrency = 'ج.س';

/// رمز الدولة الافتراضي عند كتابة رقم محلي بدون رمز (السودان)
const String kDefaultCountryCode = '+249';

/// وضع تجريبي بدون سيرفر: بيانات وهمية في الذاكرة لتجربة الواجهة والرحلة كاملة.
/// يُفعَّل عند البناء: --dart-define=DEMO=true
const bool kDemoMode = bool.fromEnvironment('DEMO', defaultValue: false);
